# Security

This is embedded hobby/repair equipment firmware. Do not use it as the sole instrument for safety-critical, medical, fire-detection, electrical-isolation, or life-safety decisions.

Report software vulnerabilities through the repository's private security reporting feature if enabled.
