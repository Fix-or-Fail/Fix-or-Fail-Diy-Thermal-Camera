# START HERE

1. Read `PINOUT.md`.
2. Wire the hardware using `WIRING_GUIDE.md` and `WIRING_DIAGRAM.txt`.
3. Check the 3V3 rail with a multimeter before attaching the GY-MCU90640.
4. Open the `.ino` under `firmware/FixOrFail_ThermalCam_V6_3_FinalProduction/`.
5. Install the libraries listed in `docs/FLASHING_GUIDE.md`.
6. Compile and upload for your ESP32-S3 N16R8 setup.
7. Power-cycle: V6.3 should start automatically from USB without Serial Monitor.
8. Run touch calibration if required.
9. For validation, run `B` and `U` from Serial Monitor at 115200 baud and compare with `docs/FINAL_VALIDATION.md`.

## Critical thermal camera wiring

- VCC → **3V3**
- GND → GND
- TX → GPIO44
- RX → GPIO43
