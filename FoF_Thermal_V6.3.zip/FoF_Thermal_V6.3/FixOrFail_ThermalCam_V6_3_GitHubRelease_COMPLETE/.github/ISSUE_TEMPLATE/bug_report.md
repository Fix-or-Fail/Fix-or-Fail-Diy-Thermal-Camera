---
name: Bug report
about: Report a reproducible firmware/hardware issue
title: '[BUG] '
labels: bug
---

## Firmware version

## ESP32-S3 board

## Thermal sensor

## TFT / touch hardware

## What happened?

## Steps to reproduce

## `D` diagnostic output

```text
paste here
```

## `U` UART stress-test output (if relevant)

```text
paste here
```

## Wiring changes from documented V6.3 pinout

