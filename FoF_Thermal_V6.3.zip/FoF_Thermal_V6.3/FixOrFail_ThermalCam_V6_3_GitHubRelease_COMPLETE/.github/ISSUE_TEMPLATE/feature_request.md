---
name: Feature request
about: Suggest an improvement
title: '[FEATURE] '
labels: enhancement
---

## Feature

## Why it would help

## Hardware changes required (if any)

