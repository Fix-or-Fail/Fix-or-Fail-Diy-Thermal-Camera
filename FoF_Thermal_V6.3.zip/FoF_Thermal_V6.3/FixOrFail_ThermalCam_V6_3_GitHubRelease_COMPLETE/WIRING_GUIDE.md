# FIX OR FAIL Thermal Camera V6.3 — COMPLETE WIRING GUIDE

## Before wiring

Disconnect USB power. Work from the **printed GPIO labels** on your ESP32-S3 rather than assuming a header position; ESP32-S3 boards can have different physical layouts.

## Step 1 — Common SPI bus

Make these three shared connections first:

```text
ESP32 GPIO13  ───── TFT SCK/CLK ───── XPT2046 T_CLK
ESP32 GPIO11  ───── TFT MOSI    ───── XPT2046 T_DIN
ESP32 GPIO12  ───── TFT MISO    ───── XPT2046 T_DO
```

## Step 2 — TFT control wiring

```text
ESP32 GPIO10  ───── TFT CS
ESP32 GPIO18  ───── TFT DC/RS
ESP32 GPIO14  ───── TFT RST
ESP32 GPIO17  ───── TFT BL/LED
ESP32 GND     ───── TFT GND
```

TFT VCC depends on the **breakout board**, not merely the LCD controller. Check the marking/specification of your exact module before connecting its VCC.

## Step 3 — Touch control wiring

```text
ESP32 GPIO9   ───── XPT2046 T_CS
ESP32 GPIO16  ───── XPT2046 T_IRQ
ESP32 GND     ───── XPT2046 GND
```

The touch controller already shares GPIO13/11/12 with the TFT from Step 1. TFT CS and touch CS must remain separate.

## Step 4 — Thermal camera UART

```text
GY-MCU90640 TX  ─── GPIO44  (ESP32 RX)
GY-MCU90640 RX  ─── GPIO43  (ESP32 TX)
GY-MCU90640 VCC ─── ESP32 3V3
GY-MCU90640 GND ─── ESP32 GND
```

**TX and RX cross over.** Do not wire TX→TX and RX→RX.

## Step 5 — Power

Preferred bench arrangement:

```text
USB cable
   │
   ▼
ESP32-S3 USB connector
   │
   ├── onboard 3.3 V rail ─── GY-MCU90640 VCC
   │
   └── GPIO/SPI/UART ──────── TFT + touch + camera data

All GND connections are common.
```

The V6.3 firmware starts automatically when USB power is applied.

### Optional physical ON/OFF switch

If you want a hard power switch while using an external regulated 5 V feed:

```text
5 V supply + ─── ON/OFF switch ─── ESP32 5V/VIN
5 V supply - ────────────────────── ESP32 GND
```

Do not place the switch between 5V and GND. Do not try to generate 5 V from a GPIO.

## Step 6 — Multimeter checks before connecting everything

1. Confirm no short between 3V3 and GND.
2. Power the ESP32 only.
3. Measure approximately 3.3 V between 3V3 and GND.
4. If using an external 5 V feed, verify approximately 5 V at the board's 5V/VIN input.
5. Power off again.
6. Connect the thermal module, TFT and touch.
7. Power on and confirm the startup screen followed by the live thermal image.

## Step 7 — First software setup

Flash `firmware/FixOrFail_ThermalCam_V6_3_FinalProduction/FixOrFail_ThermalCam_V6_3_FinalProduction.ino`.

If touch alignment is wrong, run the firmware's **8-point touch calibration**. The result is saved in NVS.

## Quick fault checks

- White/blank TFT: recheck CS/DC/RST and TFT power.
- Touch not responding: recheck T_CS GPIO9, IRQ GPIO16, and shared SPI lines.
- No thermal image: recheck **sensor TX→GPIO44**, **sensor RX→GPIO43**, 3V3 and common GND.
- Random thermal corruption: run the included `U` UART stress test in Serial Monitor at 115200 baud.
