# V6.2 Production Stable
- Increased thermal UART RX buffer from 4096 to 16384 bytes after stress testing showed a 4048-byte high-water mark.
- Added stronger streaming resynchronisation and early payload-length validation.
- Added isolated bad-pixel repair for up to three impossible samples per frame.
- Widespread corrupt frames remain rejected.
- Removed destructive automatic RX flushing after consecutive misses.
- Thermal UART now starts before the splash screen to reduce time-to-first-live-frame.
- Removed intermediate boot-status redraws on normal startup.
- Retained all V6.1 smooth-render and anti-flicker work.

# V6.1 Smooth Final

- Added cached screen-to-sensor interpolation maps to remove repeated per-pixel geometry maths.
- Raised TFT SPI target to 40 MHz for faster frame transfers.
- Uses one SPI write transaction per thermal frame with direct line writes.
- Temperature cards now repaint only changed numeric regions instead of clearing whole cards every update.
- Full-screen temperature scale no longer clears the entire rail every frame; only changed labels repaint.
- Clean-mode temperature card uses low-redraw numeric updates.
- Sensor status badge no longer repaints when its state is unchanged.
- Removed deliberate black-screen clears when switching full-screen mode.
- Preserved UART stress diagnostics and the V6 production feature set.

# V6.0 Ultimate Final

- Removed all bottom navigation tabs.
- Android-style hamburger is now the sole normal UI menu entry.
- Expanded normal thermal image from 184 px to 216 px high.
- Full-screen remains true 320x240 (native 4:3 sensor aspect).
- Corrected full-screen hotspot coordinate mapping so mirror and zoom exactly follow the full-screen thermal renderer.
- Updated production branding to V6.0 FINAL.
- Preserved V5.1.2 movable inspection, anti-flicker overlays and all proven thermal features.
