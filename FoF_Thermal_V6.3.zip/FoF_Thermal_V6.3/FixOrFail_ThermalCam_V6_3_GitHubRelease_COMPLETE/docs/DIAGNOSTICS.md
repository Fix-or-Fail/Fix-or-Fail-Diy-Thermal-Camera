# Diagnostics

## `D` — snapshot

Prints current firmware health information including FPS, sensor state, frame statistics and UART diagnostics.

## `B` — 20-second bug/stability test

Runs a non-blocking health test while you operate the UI. The final report checks sensor stream health, rejected frames, FPS, free heap, touch calibration, temperature sanity and maximum good-frame gap.

## `U` — focused 30-second UART/UI stress test

Three phases:

1. **0–10 s:** do not touch the screen.
2. **10–20 s:** use the menu, full-screen and movable cards.
3. **20–30 s:** stop touching and allow recovery.

Healthy V6.2/V6.3 reference result from the final project hardware:

```text
Total parser accepted: 119
Search timeouts: 0
Short frames: 0
Bad lengths: 0
Invalid-temperature frames: 0
Total skipped sync bytes: 0
Max skipped before header: 0
RX queue high-water: 1544 bytes
```

The 16 KB UART queue was introduced after an older 4 KB queue reached 4048 bytes and produced lost synchronisation. The final test showed the issue resolved.
