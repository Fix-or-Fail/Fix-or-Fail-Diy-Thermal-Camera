# Arduino IDE Flashing Guide

## Required software

- Arduino IDE 2.x
- Espressif ESP32 Arduino core with ESP32-S3 support

## Required libraries

Install these from Arduino Library Manager:

- **Adafruit GFX Library**
- **Adafruit ILI9341**
- **XPT2046_Touchscreen**

`SPI` and `Preferences` are supplied by the ESP32 Arduino core.

## Board settings

Use the ESP32-S3 board definition that matches your development board. The hardware used during development is an **ESP32-S3 N16R8 class board (16 MB flash / 8 MB PSRAM)**.

Typical settings to verify:

- Board: matching ESP32-S3 development module
- USB mode: whichever mode your board requires for upload/Serial
- Flash size: 16 MB when appropriate for your board
- PSRAM: enabled when your board has 8 MB PSRAM
- CPU frequency: normal ESP32-S3 operating setting

Do not blindly copy flash/partition settings from another S3 board; match the actual module.

## Upload

1. Clone/download this repository.
2. Open:
   `firmware/FixOrFail_ThermalCam_V6_3_FinalProduction/FixOrFail_ThermalCam_V6_3_FinalProduction.ino`
3. Select the correct board and COM port.
4. Verify/compile.
5. Upload.
6. Reboot or power-cycle.

The firmware does **not** wait for Serial Monitor. On a previously calibrated unit it starts the thermal UART immediately and begins normal startup as soon as power is applied.

## Serial Monitor

Set Serial Monitor to **115200 baud** for diagnostics and keyboard commands.
