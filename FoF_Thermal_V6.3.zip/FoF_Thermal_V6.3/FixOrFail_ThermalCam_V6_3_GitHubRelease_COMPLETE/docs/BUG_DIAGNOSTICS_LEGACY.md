# V6.0.1 Bug Diagnostics

This build is the V6.0 Ultimate Final firmware plus passive runtime counters.
It does not change the thermal processing or renderer behaviour.

## Quick test
1. Open Serial Monitor at **115200 baud**.
2. Let the live thermal image appear.
3. Send **B**.
4. For 20 seconds, use the camera normally: open/close the Android menu, toggle full-screen, drag a card, toggle Repair/General, and place/remove inspection points.
5. Wait for the `BUG DIAGNOSTIC REPORT`.
6. Copy the complete report back into ChatGPT if anything says `WARN`.

## Snapshot
Send **D** at any time for FPS, heap, UART/frame counters, sensor state, touch-calibration state, temperatures and maximum frame gap.

## What PASS means
- Thermal UART delivered valid frames throughout the test.
- Display FPS remained alive.
- At least 50 KB of heap headroom remained.
- Touch calibration is stored.
- Temperatures remained within the configured valid range.

A high frame-rejection percentage can indicate camera UART wiring, camera power, or synchronization problems even when the image appears to work.
