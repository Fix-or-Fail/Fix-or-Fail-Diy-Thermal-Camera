# Hardware Pinout — V6.3 Final Production

These values are taken directly from `Config.h` in the final firmware.

## ESP32-S3 → ILI9341 TFT

| TFT signal | ESP32-S3 GPIO | Notes |
|---|---:|---|
| MISO | GPIO 12 | Shared SPI data from peripheral |
| MOSI | GPIO 11 | Shared SPI data to peripheral |
| SCLK / CLK | GPIO 13 | Shared SPI clock |
| CS | GPIO 10 | TFT chip select |
| DC / RS | GPIO 18 | TFT data/command |
| RST / RESET | GPIO 14 | TFT reset |
| BL / LED | GPIO 17 | Backlight control |
| VCC | Follow your TFT breakout specification | Do not assume raw panel voltage |
| GND | GND | Common ground |

TFT SPI target speed in firmware: **40 MHz**.

## ESP32-S3 → XPT2046 Touch

The touch controller shares the TFT SPI clock/data bus.

| Touch signal | ESP32-S3 GPIO | Notes |
|---|---:|---|
| T_CLK | GPIO 13 | Shared SCLK |
| T_DIN / MOSI | GPIO 11 | Shared MOSI |
| T_DO / MISO | GPIO 12 | Shared MISO |
| T_CS | GPIO 9 | Dedicated touch chip select |
| T_IRQ | GPIO 16 | Touch interrupt |
| VCC | Follow breakout specification; logic is 3.3V | |
| GND | GND | Common ground |

Default raw calibration constants in `Config.h`:

```text
X_LEFT   = 470
X_RIGHT  = 3700
Y_TOP    = 3550
Y_BOTTOM = 380
```

The preferred setup is the firmware's **8-point calibration**, which stores the final affine calibration in NVS.

## ESP32-S3 → GY-MCU90640 UART

| Thermal module signal | ESP32-S3 pin | Direction |
|---|---:|---|
| TX | GPIO 44 (ESP32 RX) | Sensor → ESP32 |
| RX | GPIO 43 (ESP32 TX) | ESP32 → Sensor |
| VCC | 3V3 | Power |
| GND | GND | Common ground |

UART configuration: **115200 baud, 8N1**.

### Important

`GY_RX_PIN = 44` means **ESP32 GPIO44 receives the sensor's TX wire**. `GY_TX_PIN = 43` means **ESP32 GPIO43 transmits to the sensor's RX wire**.

## Power

For this project's final wiring:

```text
USB / external regulated 5V
        |
        +--> ESP32-S3 5V/VIN (board power input)
                |
                +--> onboard 3.3V regulator
                         |
                         +--> GY-MCU90640 VCC (3.3V)

All grounds must be common.
```

Never connect 5V directly to an ESP32 GPIO or the ESP32 3V3 pin.
