# V6.1 Smooth Final - lag/flicker pass

This build targets visible screen flicker and rendering latency without changing measured thermal values.

Key changes:
- interpolation coordinate maps are cached until zoom/mirror/viewport changes;
- TFT uses a 40 MHz SPI target and one batched write transaction per thermal frame;
- protected temperature cards update only the characters that changed;
- the full-screen colour scale is persistent and only its min/max labels update;
- unchanged sensor-status UI is not repainted;
- mode changes redraw directly rather than flashing the screen black first.

The existing B and U diagnostic commands are retained so the camera can be stress-tested after flashing.
