# 8-Point Touch Calibration

The XPT2046 controller is calibrated using an 8-point affine calibration routine.

## Run calibration

1. Open Serial Monitor at 115200 baud.
2. Send `T`.
3. Touch each displayed target carefully and release between points.
4. When calibration succeeds, the coefficients are stored in ESP32 NVS under the `touchcal` namespace.

## Tips

- Use a stylus if available for accurate target presses.
- Do not drag between points.
- Keep pressure steady until the point is accepted.
- Re-run calibration after changing the display/touch panel or physical orientation.

The hard-coded raw constants in `Config.h` are fallback values only; saved 8-point calibration is preferred.
