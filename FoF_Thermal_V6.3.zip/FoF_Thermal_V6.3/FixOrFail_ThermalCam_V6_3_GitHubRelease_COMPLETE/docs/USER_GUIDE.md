# User Guide

## Startup

Apply USB/5V power. The ESP32-S3 starts autonomously; a connected PC or open Serial Monitor is not required.

## Main UI

- Use the **top-left Android-style menu button** for controls.
- The old bottom tabs are intentionally removed.
- Full-screen mode uses the thermal image across the complete 320×240 display.
- Temperature cards are compact and can be moved.
- The inspection card can be hidden and repositioned.

## Movable cards

Press and hold a movable card for about 0.5 seconds, drag it, then release. Positions are stored in NVS and restored after reboot.

## Inspection points

Use P1/P2/P3 to place three measurement points. The inspection panel shows point temperatures and ΔT information. The panel can be shown/hidden and dragged.

## Key serial commands

| Command | Function |
|---|---|
| `P` | Palette |
| `F` | Freeze |
| `E` | Repair/general scene mode |
| `A` | Auto/locked range |
| `M` | Mirror |
| `Z` | Zoom 1×/2×/4× |
| `H` | Min/max hold |
| `C` | Clear hold |
| `I` | Isotherm |
| `+` / `-` | Isotherm threshold |
| `[` / `]` | Calibration offset ±0.1°C |
| `R` | Reset range |
| `T` | 8-point touch calibration |
| `D` | Diagnostic snapshot |
| `B` | 20-second stability test |
| `U` | 30-second UART/UI stress test |
| `X` | Clear measurement points |
| `Y` | Clean mode |
| `V` | Full-screen view |
| `?` | Help |
