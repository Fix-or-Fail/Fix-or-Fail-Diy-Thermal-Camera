# GitHub Publishing Guide

## Create the repository

Suggested repository name:

`FixOrFail-Thermal-Camera`

## Upload

Upload the contents of this ZIP so `README.md`, `LICENSE`, `firmware/`, `docs/`, and `.github/` are at the repository root.

## Suggested first release

Tag: `v6.3.0`

Title: `Fix Or Fail Thermal Camera V6.3 Final Production`

Suggested release summary:

> Final production firmware for ESP32-S3 + GY-MCU90640 + ILI9341 + XPT2046. Includes instant USB boot, smooth anti-flicker rendering, 16 KB UART buffering, robust sensor resynchronisation, bad-pixel repair, full-screen UI, movable inspection overlays, and built-in diagnostics. Final UART stress validation achieved 119/119 accepted frames with zero decode failures and zero skipped sync bytes.

## Before publishing

- Compile the included Arduino sketch locally.
- Flash one camera from the exact GitHub package.
- Run `B` and `U` once.
- Confirm pinout documentation matches your photographed hardware.
- Add project photos/screenshots to the README if you want a more attractive GitHub page.
