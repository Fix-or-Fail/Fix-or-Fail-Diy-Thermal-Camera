# V6.0.2 Focused UART Stress Test

Flash this diagnostic build and open Serial Monitor at 115200 baud. Send `U`.

The 30 second test has three phases:
1. 0-10 s: do not touch the screen.
2. 10-20 s: actively open/close the menu, toggle full screen, and move cards.
3. 20-30 s: stop touching and let the camera recover.

Paste the entire three-phase report back into ChatGPT. The added counters distinguish:
- parser/header synchronization problems (skipped bytes, bad lengths, short frames),
- malformed/corrupted accepted payloads (invalid-temperature frames), and
- UI/render blocking (UI/render/read-gap timing and RX queue high-water).

Thermal calculations and rendering behaviour are otherwise unchanged from V6.0.1.
