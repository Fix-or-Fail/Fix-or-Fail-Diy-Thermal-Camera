# Wiring Guide

## 1. Power off first

Disconnect USB before moving wires. Confirm the board's printed pin labels rather than relying only on board position, because ESP32-S3 development-board layouts vary.

## 2. Wire the TFT SPI bus

Connect TFT `SCLK→GPIO13`, `MOSI→GPIO11`, `MISO→GPIO12`, `CS→GPIO10`, `DC→GPIO18`, `RST→GPIO14`, and `BL→GPIO17`.

## 3. Wire the XPT2046 touch controller

The touch controller shares `SCLK/MOSI/MISO` with the TFT. Add `T_CS→GPIO9` and `T_IRQ→GPIO16`.

Each SPI peripheral must have its own CS line. Do not tie TFT CS and touch CS together.

## 4. Wire the thermal camera UART

- GY-MCU90640 `TX → ESP32 GPIO44 (RX)`
- GY-MCU90640 `RX → ESP32 GPIO43 (TX)`
- GY-MCU90640 `VCC → ESP32 3V3`
- GY-MCU90640 `GND → ESP32 GND`

TX and RX cross over by design.

## 5. Power the ESP32-S3

The final project can start automatically whenever it receives USB power. If using an external switched 5V source instead of the board's USB connector, route the regulated 5V supply through the ON/OFF switch and then to the board's correct `5V/VIN` input. Ground bypasses the switch and remains common.

Do not feed the board through both a separate 5V source and USB unless your particular board explicitly supports that arrangement.

## 6. First power-on checks

Before connecting every peripheral, verify with a multimeter:

- 5V/VIN rail: approximately 5V when powered from a suitable 5V source.
- 3V3 rail: approximately 3.3V.
- No short between power and GND.

Then attach peripherals one at a time if troubleshooting a voltage drop.
