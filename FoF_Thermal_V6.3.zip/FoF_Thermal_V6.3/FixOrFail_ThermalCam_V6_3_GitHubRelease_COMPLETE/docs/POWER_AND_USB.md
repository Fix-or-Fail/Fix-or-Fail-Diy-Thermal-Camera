# Power and USB

## Instant startup

The production firmware is designed to begin automatically as soon as the ESP32-S3 receives power. It does not wait for Serial Monitor or USB enumeration.

The thermal UART is started early in boot so sensor bytes can begin accumulating while the display initializes.

## Thermal camera power

The GY-MCU90640 in this project is on the **3.3V rail**.

## Physical ON/OFF switch with a fixed USB/external 5V supply

If you are not using a battery and want a hard power switch, switch the **incoming 5V supply before the ESP32's 5V/VIN input**:

```text
5V supply +  ---- ON/OFF SWITCH ----  ESP32 5V/VIN
5V supply -  ------------------------  ESP32 GND

ESP32 3V3  --------------------------  GY-MCU90640 VCC
ESP32 GND  --------------------------  GY-MCU90640 GND
```

If you instead power through the board's USB-C connector, a switch connected only to the 5V/VIN header will not disconnect USB power. Use an inline USB power switch/cable or switch the 5V source before it reaches the board.
