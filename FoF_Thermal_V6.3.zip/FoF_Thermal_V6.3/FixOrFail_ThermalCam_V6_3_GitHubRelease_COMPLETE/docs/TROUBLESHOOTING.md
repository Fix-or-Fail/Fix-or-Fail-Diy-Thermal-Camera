# Troubleshooting

## Screen is blank

- Confirm TFT power and ground.
- Confirm `CS=10`, `DC=18`, `RST=14`, `SCLK=13`, `MOSI=11`, `MISO=12`.
- Confirm the display module is actually ILI9341-compatible.

## Touch is offset

Run the 8-point calibration with serial command `T`.

## Thermal image does not appear

- Confirm GY-MCU90640 is powered from 3.3V and shares GND.
- Confirm sensor `TX→GPIO44` and sensor `RX→GPIO43`.
- Run `D` and `U` at 115200 baud.

## Random 300°C+ pixels

V6.3 contains isolated bad-pixel repair and stronger UART resynchronisation. If these return, run `U`. Non-zero skipped sync bytes, invalid frames or a UART queue approaching 16 KB indicate a wiring, power, signal-integrity or regression issue.

## Flickering numbers/overlays

V6.3 contains the V6.1 low-redraw anti-flicker system. If flicker appears after editing the renderer, check that overlay/card rectangles remain excluded from thermal image repaint regions.

## Lag

Reference worst render time from the validated build was around 169–170 ms. If significantly higher:

- check TFT SPI wiring quality,
- ensure no unnecessary full-screen clears were reintroduced,
- verify 40 MHz SPI remains stable on your wiring,
- run `U` and compare render/read-gap timings.

## Only ~3V on a supposed 5V pin

Firmware cannot create a 5V GPIO output. Verify you are measuring the board's actual 5V/VBUS/VIN rail, the USB cable/source is good, and the rail is not overloaded. Never apply 5V to `3V3` or any GPIO.
