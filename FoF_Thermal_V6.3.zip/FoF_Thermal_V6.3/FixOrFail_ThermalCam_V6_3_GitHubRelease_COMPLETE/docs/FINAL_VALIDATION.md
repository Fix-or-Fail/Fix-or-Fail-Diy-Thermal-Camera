# Fix Or Fail Thermal Camera V6.3 Final Production

This release intentionally freezes the validated V6.2 production-stable core rather than adding new experimental behaviour.

## Validation basis
The final V6.2 UART/UI stress run reported:
- 119 parser-accepted frames across idle, UI-stress and recovery phases
- 0 decode failures
- 0 search timeouts
- 0 short frames
- 0 bad-length frames
- 0 invalid-temperature frames
- 0 skipped sync bytes
- UART queue high-water: 1544 bytes with a 16 KB RX queue
- maximum render time: ~170 ms
- UI-stress phase: 0 UART/frame errors

## Final production features
- Immediate autonomous startup from USB power; does not wait for Serial Monitor
- 16 KB UART RX queue and robust frame resynchronisation
- isolated bad-pixel repair with corrupt-frame rejection
- smooth/anti-flicker renderer
- full-screen thermal view and Android-style top menu
- compact movable temperature cards
- movable/hideable inspection card and P1/P2/P3 Delta-T measurements
- Repair Mode, Isotherm, Smart Hotspot, Edge Assist and palettes
- settings persistence, touch calibration, diagnostics and recovery

## Release policy
V6.3 changes production naming/documentation only. Thermal acquisition, decoding, temperature calculations, filtering, rendering behaviour and UI logic are inherited from the stress-tested V6.2 core.
