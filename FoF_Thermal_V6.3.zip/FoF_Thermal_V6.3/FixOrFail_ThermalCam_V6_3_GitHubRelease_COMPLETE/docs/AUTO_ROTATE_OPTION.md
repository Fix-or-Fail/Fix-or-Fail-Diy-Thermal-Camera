# Optional Future Auto-Rotate

V6.3 does not automatically rotate based on physical orientation because the current hardware has no confirmed accelerometer/IMU.

To add phone-style auto-rotation later, add a small 3-axis accelerometer such as an LIS3DH-class device on spare I2C pins. Firmware can then select 0°, 90°, 180° or 270° orientation with hysteresis so the UI does not flip repeatedly near a boundary.

A correct implementation must rotate together:

- thermal image coordinates,
- touch coordinates/calibration,
- hotspot/coldspot overlays,
- P1/P2/P3 positions,
- temperature cards,
- inspection panel,
- temperature scale and menus.

Do not enable automatic rotation in software without a real orientation sensor; the ESP32-S3 cannot infer physical rotation from the thermal sensor alone.
