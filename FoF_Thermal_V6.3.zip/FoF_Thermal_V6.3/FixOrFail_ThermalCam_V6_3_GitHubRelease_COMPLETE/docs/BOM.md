# Bill of Materials

Core parts used by V6.3:

| Part | Requirement |
|---|---|
| ESP32-S3 development board | N16R8 class used during development |
| Thermal sensor | GY-MCU90640 UART, 32×24 |
| TFT | ILI9341, 320×240, SPI |
| Touch | XPT2046 resistive touch controller |
| USB/5V supply | Stable supply suitable for the complete assembled load |
| Wiring | Short, reliable SPI/UART connections recommended |
| Optional switch | Latching switch in the incoming 5V power path |

Exact breakout-board power requirements vary. Check the markings/datasheet for your specific TFT module rather than assuming every ILI9341 breakout accepts the same VCC voltage.
