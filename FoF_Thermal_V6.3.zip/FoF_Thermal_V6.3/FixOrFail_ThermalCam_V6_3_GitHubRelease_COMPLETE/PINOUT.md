# FIX OR FAIL Thermal Camera V6.3 — FINAL PINOUT

> **Use this pinout with the included V6.3 firmware. These GPIO values match `firmware/FixOrFail_ThermalCam_V6_3_FinalProduction/Config.h`.**

## ESP32-S3 ↔ ILI9341 TFT

| ILI9341 pin | ESP32-S3 |
|---|---|
| SCK / CLK | GPIO 13 |
| MOSI / SDI | GPIO 11 |
| MISO / SDO | GPIO 12 |
| CS | GPIO 10 |
| DC / RS | GPIO 18 |
| RST / RESET | GPIO 14 |
| BL / LED | GPIO 17 |
| GND | GND |
| VCC | **Use the voltage specified by your TFT breakout board** |

## ESP32-S3 ↔ XPT2046 Touch

The XPT2046 shares the SPI data/clock lines with the TFT.

| XPT2046 pin | ESP32-S3 |
|---|---|
| T_CLK | GPIO 13 |
| T_DIN / MOSI | GPIO 11 |
| T_DO / MISO | GPIO 12 |
| T_CS | GPIO 9 |
| T_IRQ | GPIO 16 |
| GND | GND |
| VCC | Use breakout-board specification; ESP32 logic is 3.3 V |

## ESP32-S3 ↔ GY-MCU90640 thermal camera

| GY-MCU90640 | ESP32-S3 | Important |
|---|---|---|
| TX | GPIO 44 | Sensor TX goes to ESP32 RX |
| RX | GPIO 43 | Sensor RX goes to ESP32 TX |
| VCC | **3V3** | Thermal camera is powered from 3.3 V in this build |
| GND | GND | Common ground |

UART: **115200 baud, 8N1**.

## Power

The ESP32-S3 itself can be powered from its normal USB connector. The firmware boots automatically as soon as the board receives power; Serial Monitor is not required.

If instead using a separate regulated 5 V supply, feed the board's correctly labelled **5V/VIN input**, not a GPIO and never the 3V3 pin. Board layouts vary, so identify the physical 5V/VIN pin from the markings on your exact board.

**Do not apply 5 V to the GY-MCU90640 in this project. It is wired to 3V3.**
