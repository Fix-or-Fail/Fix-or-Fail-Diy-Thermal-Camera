#pragma once

#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ILI9341.h>

#include "Config.h"

class Display {
public:
  Display();

  void begin();
  void clear();

  Adafruit_ILI9341& tft();
  SPIClass& spi();

  void setInspectionCardVisible(bool visible);
  void setInspectionCardRect(int x, int y);
  void setFullScreen(bool enabled);
  void setInfoCardRects(bool visible, int centreX, int centreY, int statsX, int statsY);
  void setTemperatureScaleReserved(bool reserved);
  void setTopOverlayReserved(bool reserved);

  void renderImage(
    const float* filteredGrid,
    float displayMinimum,
    float displayMaximum,
    bool mirrorImage,
    uint8_t zoomLevel,
    bool isothermEnabled,
    float isothermThreshold
  );

private:
  SPIClass displaySPI;
  Adafruit_ILI9341 screen;

  uint16_t lineBuffer[SCREEN_WIDTH];
  uint8_t mapX0[SCREEN_WIDTH], mapX1[SCREEN_WIDTH];
  uint8_t mapY0[SCREEN_HEIGHT], mapY1[SCREEN_HEIGHT];
  float mapXF[SCREEN_WIDTH], mapYF[SCREEN_HEIGHT];
  int cachedMapWidth = -1, cachedMapHeight = -1;
  bool cachedMapMirror = false;
  uint8_t cachedMapZoom = 0;
  float edgeAssistGrid[PIXEL_COUNT];
  float v4SpatialGrid[PIXEL_COUNT];
  float v4QualityGrid[PIXEL_COUNT];
  float v4HistoryGrid[PIXEL_COUNT];
  bool v4HistoryValid = false;
  bool inspectionCardVisible = false;
  int inspectionCardX = PROBE_CARD_X;
  int inspectionCardY = PROBE_CARD_Y;
  bool fullScreenEnabled = false;
  bool infoCardsVisible = true;
  bool temperatureScaleReserved = false;
  bool topOverlayReserved = false;
  int centreCardX = 8, centreCardY = 30;
  int statsCardX = 226, statsCardY = 30;

  void buildV4QualityGrid(
    const float* sourceGrid,
    float displayMinimum,
    float displayMaximum
  );

  void buildEdgeAssistGrid(
    const float* sourceGrid,
    float displayMinimum,
    float displayMaximum
  );

  void ensureInterpolationMap(int viewportWidth, int viewportHeight, bool mirrorImage, uint8_t zoomLevel);
  inline float interpolateMapped(const float* grid, int imageX, int imageY) const;
};
