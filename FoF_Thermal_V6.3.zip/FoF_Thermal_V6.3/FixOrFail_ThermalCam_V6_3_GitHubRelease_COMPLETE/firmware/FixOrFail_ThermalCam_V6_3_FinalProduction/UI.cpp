#include "UI.h"
#include "LogoBitmap.h"

static constexpr uint16_t BG = 0x18E3;
static constexpr uint16_t CARD = 0x2945;
static constexpr uint16_t ACCENT = ILI9341_ORANGE;
static constexpr int DRAWER_WIDTH = 250;

void UI::showBootScreen(Adafruit_ILI9341& tft)
{
  tft.fillScreen(ILI9341_BLACK);
  tft.drawRGBBitmap(0, 0, FIX_OR_FAIL_LOGO, LOGO_WIDTH, LOGO_HEIGHT);
  tft.fillRect(0, 180, 320, 60, ILI9341_BLACK);
  tft.drawFastHLine(0, 180, 320, ACCENT);
  tft.setTextWrap(false);
  tft.setTextSize(2);
  tft.setTextColor(ILI9341_WHITE, ILI9341_BLACK);
  tft.setCursor(12, 190); tft.print("THERMAL CAMERA");
  tft.setTextColor(ACCENT, ILI9341_BLACK);
  tft.setCursor(210, 190); tft.print("V6.2");
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_LIGHTGREY, ILI9341_BLACK);
  tft.setCursor(12, 218); tft.print("REPAIR. TEST. FAIL. FIX. REPEAT.");
  showBootStatus(tft, "INITIALISING THERMAL CORE", false);
  // No fixed splash delay: the logo remains until the first valid thermal frame.
}


void UI::showBootStatus(Adafruit_ILI9341& tft, const char* status, bool ready)
{
  // Small protected status strip: feels like an appliance boot screen without
  // adding a fixed delay to startup.
  constexpr int x = 12;
  constexpr int y = 232;
  tft.fillRect(x, y, 296, 8, ILI9341_BLACK);
  tft.fillCircle(x + 3, y + 3, 3, ready ? ILI9341_GREEN : ACCENT);
  tft.setTextSize(1);
  tft.setTextColor(ready ? ILI9341_GREEN : ILI9341_LIGHTGREY, ILI9341_BLACK);
  tft.setCursor(x + 11, y);
  tft.print(status);
}

void UI::updateSensorStatus(Adafruit_ILI9341& tft, bool online)
{
  // Do not repaint an unchanged badge. Repeated fillRoundRect calls in the
  // header were visible as a small periodic flash on otherwise stable video.
  if (sensorCacheValid && cachedSensorOnline == online) return;
  constexpr int x = 242;
  constexpr int y = 3;
  constexpr int w = 74;
  constexpr int h = 18;
  tft.fillRoundRect(x, y, w, h, 5, BG);
  tft.fillCircle(x + 8, y + 9, 3, online ? ILI9341_GREEN : ILI9341_RED);
  tft.setTextSize(1);
  tft.setTextColor(online ? ILI9341_GREEN : ILI9341_RED, BG);
  tft.setCursor(x + 16, y + 6);
  tft.print(online ? "SENSOR OK" : "NO SENSOR");
  cachedSensorOnline = online;
  sensorCacheValid = true;
}

void UI::navButton(Adafruit_ILI9341& tft, int index, const char* label, bool active)
{
  const int x = index * 64;
  const int y = SCREEN_HEIGHT - NAV_HEIGHT;
  const uint16_t fill = active ? ACCENT : BG;
  tft.fillRect(x, y, 64, NAV_HEIGHT, fill);
  if (index > 0) tft.drawFastVLine(x, y + 6, NAV_HEIGHT - 12, ILI9341_DARKGREY);
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, fill);
  const int textX = x + (64 - static_cast<int>(strlen(label)) * 6) / 2;
  tft.setCursor(textX, y + 12);
  tft.print(label);
}

void UI::drawHomeChrome(Adafruit_ILI9341& tft, PaletteMode paletteMode,
                        bool freezeFrame, bool autoRange, uint8_t zoomLevel, bool fullScreen)
{
  (void)paletteMode;
  if (fullScreen) return;
  sensorCacheValid = false;
  tft.fillRect(0, 0, SCREEN_WIDTH, HEADER_HEIGHT, BG);

  // Android-style hamburger button.
  tft.drawFastHLine(9, 7, 15, ILI9341_WHITE);
  tft.drawFastHLine(9, 11, 15, ILI9341_WHITE);
  tft.drawFastHLine(9, 15, 15, ILI9341_WHITE);

  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, BG);
  tft.setCursor(34, 8); tft.print("FIX OR FAIL");
  tft.setTextColor(ACCENT, BG);
  tft.setCursor(128, 8); tft.print("V6.3 FINAL");
  tft.fillRoundRect(FULLSCREEN_BUTTON_X, FULLSCREEN_BUTTON_Y, FULLSCREEN_BUTTON_W, FULLSCREEN_BUTTON_H, 5, ILI9341_DARKGREY);
  tft.setTextSize(1); tft.setTextColor(ILI9341_WHITE, ILI9341_DARKGREY);
  tft.setCursor(FULLSCREEN_BUTTON_X + 8, FULLSCREEN_BUTTON_Y + 6); tft.print("FULL");
  // V6.0: bottom navigation removed. The Android-style hamburger is the single UI entry point.
  // This leaves the entire lower display available to the thermal image.
}

void UI::quickButton(Adafruit_ILI9341& tft, int index, const char* label, bool active)
{
  constexpr int w = 60;
  const int x = 5 + index * (w + QUICK_BUTTON_GAP);
  const uint16_t fill = active ? ACCENT : ILI9341_BLACK;
  tft.fillRoundRect(x, QUICK_BAR_Y, w, QUICK_BUTTON_H, 6, fill);
  tft.drawRoundRect(x, QUICK_BAR_Y, w, QUICK_BUTTON_H, 6, active ? ILI9341_WHITE : ILI9341_DARKGREY);
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, fill);
  const int tx = x + (w - static_cast<int>(strlen(label)) * 6) / 2;
  tft.setCursor(tx, QUICK_BAR_Y + 8);
  tft.print(label);
}

void UI::drawFullScreenControls(Adafruit_ILI9341& tft, bool freezeFrame,
                                bool autoRange, bool cleanMode)
{
  quickButton(tft, 0, "UI", false);
  quickButton(tft, 1, "PAL", false);
  quickButton(tft, 2, freezeFrame ? "LIVE" : "HOLD", freezeFrame);
  quickButton(tft, 3, autoRange ? "AUTO" : "LOCK", autoRange);
  quickButton(tft, 4, "MENU", cleanMode);
}

void UI::invalidateDynamicOverlays()
{
  overlayCacheValid = false;
  scaleCacheValid = false;
  cleanCacheValid = false;
  sensorCacheValid = false;
}

void UI::drawTemperatureScale(Adafruit_ILI9341& tft, float minimum, float maximum)
{
  if (maximum <= minimum) return;

  const int roundedMax = static_cast<int>(lroundf(maximum));
  const int roundedMin = static_cast<int>(lroundf(minimum));

  // The thermal renderer permanently reserves this rail. Draw the expensive
  // gradient only once (or after a palette/layout invalidation), then update
  // only the tiny numeric label areas. That removes the black wipe/flicker.
  if (!scaleCacheValid) {
    tft.fillRect(SCALE_RAIL_X, 0, SCREEN_WIDTH - SCALE_RAIL_X, SCREEN_HEIGHT, ILI9341_BLACK);
    for (int y = 0; y < SCALE_H; ++y) {
      const int index = 255 - (y * 255 / max(1, SCALE_H - 1));
      tft.drawFastHLine(SCALE_X, SCALE_Y + y, SCALE_W, paletteColour(index));
    }
    tft.drawRect(SCALE_X - 1, SCALE_Y - 1, SCALE_W + 2, SCALE_H + 2, ILI9341_WHITE);
  }

  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, ILI9341_BLACK);
  char value[12];
  int16_t x1, y1; uint16_t w, h;

  if (!scaleCacheValid || roundedMax != cachedScaleMax) {
    tft.fillRect(SCALE_RAIL_X, SCALE_Y - 18, SCREEN_WIDTH - SCALE_RAIL_X, 14, ILI9341_BLACK);
    snprintf(value, sizeof(value), "%dC", roundedMax);
    tft.getTextBounds(value, 0, 0, &x1, &y1, &w, &h);
    tft.setCursor(SCALE_X + SCALE_W / 2 - static_cast<int>(w) / 2, SCALE_Y - 14);
    tft.print(value);
  }

  if (!scaleCacheValid || roundedMin != cachedScaleMin) {
    tft.fillRect(SCALE_RAIL_X, SCALE_Y + SCALE_H + 4, SCREEN_WIDTH - SCALE_RAIL_X, 16, ILI9341_BLACK);
    snprintf(value, sizeof(value), "%dC", roundedMin);
    tft.getTextBounds(value, 0, 0, &x1, &y1, &w, &h);
    tft.setCursor(SCALE_X + SCALE_W / 2 - static_cast<int>(w) / 2, SCALE_Y + SCALE_H + 7);
    tft.print(value);
  }

  cachedScaleMax = roundedMax;
  cachedScaleMin = roundedMin;
  scaleCacheValid = true;
}


void UI::drawCleanOverlay(Adafruit_ILI9341& tft, float spot, float hotTemperature)
{
  const int spot10 = static_cast<int>(lroundf(spot * 10.0f));
  if (!cleanCacheValid) {
    tft.fillRoundRect(CLEAN_CARD_X, CLEAN_CARD_Y, CLEAN_CARD_W, CLEAN_CARD_H, 7, CARD);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_LIGHTGREY, CARD);
    tft.setCursor(CLEAN_CARD_X + 7, CLEAN_CARD_Y + 5); tft.print("CENTRE");
  }
  if (!cleanCacheValid || spot10 != cachedCleanSpot10) {
    tft.fillRect(CLEAN_CARD_X + 5, CLEAN_CARD_Y + 15, CLEAN_CARD_W - 10, 13, CARD);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_WHITE, CARD);
    tft.setCursor(CLEAN_CARD_X + 7, CLEAN_CARD_Y + 17); tft.print(spot, 1); tft.print(" C");
  }
  cachedCleanSpot10 = spot10;
  cleanCacheValid = true;
  (void)hotTemperature;
}


void UI::menuRow(Adafruit_ILI9341& tft, int row, const char* label, bool enabled)
{
  constexpr int PANEL_X = 38;
  constexpr int PANEL_Y = 24;
  constexpr int PANEL_W = 244;
  const int x = PANEL_X + 12;
  const int y = PANEL_Y + 37 + row * 31;

  tft.fillRoundRect(x, y, PANEL_W - 24, 27, 6, CARD);
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, CARD);
  tft.setCursor(x + 10, y + 10);
  tft.print(label);

  const int switchX = x + PANEL_W - 69;
  tft.fillRoundRect(switchX, y + 6, 36, 15, 8,
                    enabled ? ACCENT : ILI9341_DARKGREY);
  tft.fillCircle(enabled ? switchX + 28 : switchX + 8,
                 y + 13, 5, ILI9341_WHITE);
}


void UI::isothermRow(Adafruit_ILI9341& tft, int row, bool enabled, float threshold)
{
  constexpr int PANEL_X = 38;
  constexpr int PANEL_Y = 24;
  constexpr int PANEL_W = 244;
  const int x = PANEL_X + 12;
  const int y = PANEL_Y + 37 + row * 31;

  tft.fillRoundRect(x, y, PANEL_W - 24, 27, 6, CARD);
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, CARD);
  tft.setCursor(x + 10, y + 10);
  tft.print("ISOTHERM");

  tft.fillRoundRect(x + 88, y + 5, 25, 17, 5, ILI9341_DARKGREY);
  tft.fillRoundRect(x + 184, y + 5, 25, 17, 5, ILI9341_DARKGREY);
  tft.setTextColor(ILI9341_WHITE, ILI9341_DARKGREY);
  tft.setCursor(x + 98, y + 10); tft.print("-");
  tft.setCursor(x + 194, y + 10); tft.print("+");

  const int valueX = x + 118;
  tft.fillRoundRect(valueX, y + 5, 61, 17, 5, enabled ? ACCENT : ILI9341_DARKGREY);
  tft.setTextColor(ILI9341_WHITE, enabled ? ACCENT : ILI9341_DARKGREY);
  tft.setCursor(valueX + 7, y + 10);
  tft.print(threshold, 0); tft.print("C");
}

void UI::drawMenu(Adafruit_ILI9341& tft, bool electronicsMode,
                  bool mirrorImage, bool minMaxHold, bool isothermEnabled,
                  float isothermThreshold)
{
  // Instant floating panel: no animation and no repeated full-screen redraw.
  constexpr int PANEL_X = 38;
  constexpr int PANEL_Y = 24;
  constexpr int PANEL_W = 244;
  constexpr int PANEL_H = 192;

  // Simple dark outline gives the panel separation without expensive effects.
  tft.fillRoundRect(PANEL_X - 2, PANEL_Y - 2, PANEL_W + 4, PANEL_H + 4,
                    10, ILI9341_BLACK);
  tft.fillRoundRect(PANEL_X, PANEL_Y, PANEL_W, PANEL_H, 9, BG);
  tft.drawRoundRect(PANEL_X, PANEL_Y, PANEL_W, PANEL_H, 9, ILI9341_DARKGREY);

  tft.setTextSize(2);
  tft.setTextColor(ILI9341_WHITE, BG);
  tft.setCursor(PANEL_X + 14, PANEL_Y + 12);
  tft.print("SETTINGS");
  tft.setTextSize(1);
  tft.setTextColor(ACCENT, BG);
  tft.setCursor(PANEL_X + 190, PANEL_Y + 17);
  tft.print("V5.1");

  menuRow(tft, 0, "REPAIR MODE", electronicsMode);
  menuRow(tft, 1, "MIRROR IMAGE", mirrorImage);
  menuRow(tft, 2, "MIN / MAX HOLD", minMaxHold);
  isothermRow(tft, 3, isothermEnabled, isothermThreshold);

  const int by = PANEL_Y + 164;
  tft.fillRoundRect(PANEL_X + 12, by, 68, 22, 6, CARD);
  tft.fillRoundRect(PANEL_X + 88, by, 68, 22, 6, CARD);
  tft.fillRoundRect(PANEL_X + 164, by, 68, 22, 6, ACCENT);

  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, CARD);
  tft.setCursor(PANEL_X + 18, by + 8); tft.print("CALIBRATE");
  tft.setCursor(PANEL_X + 108, by + 8); tft.print("DIAG");
  tft.setTextColor(ILI9341_WHITE, ACCENT);
  tft.setCursor(PANEL_X + 187, by + 8); tft.print("MORE");

  menuVisible = true;
}

void UI::drawSystemMenu(Adafruit_ILI9341& tft, bool cleanMode, bool startFullScreen,
                        bool temperatureScaleEnabled, bool resetArmed)
{
  constexpr int PANEL_X = 38, PANEL_Y = 24, PANEL_W = 244, PANEL_H = 192;
  tft.fillRoundRect(PANEL_X - 2, PANEL_Y - 2, PANEL_W + 4, PANEL_H + 4, 10, ILI9341_BLACK);
  tft.fillRoundRect(PANEL_X, PANEL_Y, PANEL_W, PANEL_H, 9, BG);
  tft.drawRoundRect(PANEL_X, PANEL_Y, PANEL_W, PANEL_H, 9, ILI9341_DARKGREY);
  tft.setTextSize(2); tft.setTextColor(ILI9341_WHITE, BG);
  tft.setCursor(PANEL_X + 14, PANEL_Y + 12); tft.print("SYSTEM");
  tft.setTextSize(1); tft.setTextColor(ACCENT, BG);
  tft.setCursor(PANEL_X + 190, PANEL_Y + 17); tft.print("V5.1");

  menuRow(tft, 0, "YOUTUBE CLEAN", cleanMode);
  menuRow(tft, 1, "START FULLSCREEN", startFullScreen);
  menuRow(tft, 2, "TEMP SCALE", temperatureScaleEnabled);

  const int by = PANEL_Y + 164;
  tft.fillRoundRect(PANEL_X + 12, by, 68, 22, 6, CARD);
  tft.fillRoundRect(PANEL_X + 88, by, 68, 22, 6, resetArmed ? ILI9341_RED : CARD);
  tft.fillRoundRect(PANEL_X + 164, by, 68, 22, 6, ACCENT);
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, CARD);
  tft.setCursor(PANEL_X + 30, by + 8); tft.print("ABOUT");
  tft.setTextColor(ILI9341_WHITE, resetArmed ? ILI9341_RED : CARD);
  tft.setCursor(PANEL_X + 99, by + 8); tft.print(resetArmed ? "CONFIRM" : "FACTORY");
  tft.setTextColor(ILI9341_WHITE, ACCENT);
  tft.setCursor(PANEL_X + 187, by + 8); tft.print("BACK");
  menuVisible = true;
}

void UI::showAbout(Adafruit_ILI9341& tft, bool sensorOnline, bool touchCalibrated,
                   uint32_t uptimeSeconds)
{
  tft.fillScreen(BG);
  tft.fillRect(0, 0, SCREEN_WIDTH, HEADER_HEIGHT, ILI9341_BLACK);
  tft.setTextSize(1); tft.setTextColor(ILI9341_WHITE, ILI9341_BLACK);
  tft.setCursor(10, 8); tft.print("FIX OR FAIL THERMAL CAMERA PRO");
  tft.fillRoundRect(12, 34, 296, 158, 9, CARD);
  tft.setTextColor(ACCENT, CARD); tft.setTextSize(2);
  tft.setCursor(24, 48); tft.print("V5.1 PRODUCTION");
  tft.setTextSize(1); tft.setTextColor(ILI9341_WHITE, CARD);
  int y = 82;
  auto line=[&](const char* k, const char* v){
    tft.setTextColor(ILI9341_LIGHTGREY, CARD); tft.setCursor(24,y); tft.print(k);
    tft.setTextColor(ILI9341_WHITE, CARD); tft.setCursor(154,y); tft.print(v); y+=18;
  };
  line("MCU", "ESP32-S3 N16R8");
  line("THERMAL", "GY-MCU90640 32x24");
  line("DISPLAY", "ILI9341 320x240");
  line("TOUCH", touchCalibrated ? "XPT2046 CAL OK" : "CAL REQUIRED");
  line("SENSOR", sensorOnline ? "ONLINE" : "OFFLINE");
  char up[24]; snprintf(up,sizeof(up),"%lu s", static_cast<unsigned long>(uptimeSeconds)); line("UPTIME", up);
  tft.fillRoundRect(64, 208, 192, 24, 6, ACCENT);
  tft.setTextColor(ILI9341_WHITE, ACCENT); tft.setCursor(111, 217); tft.print("TAP TO RETURN");
}

void UI::closeMenu(Adafruit_ILI9341& tft)
{
  (void)tft;
  // Do not clear the panel to black. The next image redraw replaces it in one pass,
  // which avoids the visible black flash seen in V8.1.1.
  menuVisible = false;
}

void UI::showDiagnostics(Adafruit_ILI9341& tft, float fps, uint32_t freeHeap,
                         uint32_t rejectedFrames, float rangeMinimum,
                         float rangeMaximum, float spot, float minimum,
                         float maximum, PaletteMode paletteMode, uint8_t zoomLevel)
{
  tft.fillScreen(BG);
  tft.fillRect(0, 0, SCREEN_WIDTH, HEADER_HEIGHT, ILI9341_BLACK);
  tft.setTextWrap(false);
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, ILI9341_BLACK);
  tft.setCursor(10, 8); tft.print("FIX OR FAIL");
  tft.setTextColor(ACCENT, ILI9341_BLACK);
  tft.setCursor(124, 8); tft.print("V5.1 DIAG");

  const int x = 12;
  int y = 34;
  tft.fillRoundRect(8, 29, 304, 171, 8, CARD);
  tft.setTextSize(1);
  auto row = [&](const char* label) {
    tft.setTextColor(ILI9341_LIGHTGREY, CARD);
    tft.setCursor(x, y); tft.print(label);
    tft.setTextColor(ILI9341_WHITE, CARD);
    tft.setCursor(142, y);
  };

  row("FRAME RATE"); tft.print(fps, 2); tft.print(" FPS"); y += 19;
  row("FREE HEAP"); tft.print(freeHeap); tft.print(" B"); y += 19;
  row("REJECTED FRAMES"); tft.print(rejectedFrames); y += 19;
  row("DISPLAY RANGE"); tft.print(rangeMinimum, 1); tft.print(" - "); tft.print(rangeMaximum, 1); tft.print(" C"); y += 19;
  row("CENTRE TEMP"); tft.print(spot, 1); tft.print(" C"); y += 19;
  row("MIN / MAX"); tft.print(minimum, 1); tft.print(" / "); tft.print(maximum, 1); tft.print(" C"); y += 19;
  row("PALETTE ID"); tft.print(static_cast<int>(paletteMode)); y += 19;
  row("ZOOM"); tft.print(zoomLevel); tft.print("X");

  tft.fillRoundRect(64, 210, 192, 22, 6, ACCENT);
  tft.setTextColor(ILI9341_WHITE, ACCENT);
  tft.setCursor(105, 218); tft.print("TAP TO RETURN");
}

void UI::drawCrosshair(Adafruit_ILI9341& tft)
{
  const int x = IMAGE_X + IMAGE_WIDTH / 2;
  const int y = IMAGE_Y + IMAGE_HEIGHT / 2;
  tft.drawFastHLine(x - 7, y, 15, ILI9341_BLACK);
  tft.drawFastVLine(x, y - 7, 15, ILI9341_BLACK);
  tft.drawFastHLine(x - 5, y, 11, ILI9341_WHITE);
  tft.drawFastVLine(x, y - 5, 11, ILI9341_WHITE);
  tft.drawPixel(x, y, ACCENT);
}

void UI::drawMeasurementPoints(Adafruit_ILI9341& tft, const bool enabled[3],
                               const int screenX[3], const int screenY[3],
                               const float temperatures[3], int cardX, int cardY,
                               bool cardVisible)
{
  static const uint16_t pointColours[3] = {
    ILI9341_YELLOW, ILI9341_GREEN, ILI9341_MAGENTA
  };

  uint8_t activeCount = 0;
  for (uint8_t i = 0; i < 3; ++i) {
    if (!enabled[i]) continue;
    ++activeCount;
    const int x = screenX[i];
    const int y = screenY[i];
    const uint16_t colour = pointColours[i];

    // Small marker only. Temperature labels were previously painted on top of
    // the moving thermal image every frame, which made the whole view appear to blink.
    tft.drawCircle(x, y, 7, ILI9341_BLACK);
    tft.drawCircle(x, y, 6, colour);
    tft.drawFastHLine(x - 9, y, 19, colour);
    tft.drawFastVLine(x, y - 9, 19, colour);
    tft.fillCircle(x, y, 2, ILI9341_BLACK);
    tft.setTextSize(1);
    tft.setTextColor(colour, ILI9341_BLACK);
    tft.setCursor(constrain(x + 8, IMAGE_X, IMAGE_X + IMAGE_WIDTH - 14),
                  constrain(y + 6, IMAGE_Y, IMAGE_Y + IMAGE_HEIGHT - 8));
    tft.print("P"); tft.print(i + 1);
  }

  if (activeCount == 0) return;

  if (!cardVisible) {
    // The card can be restored by tapping any P1/P2/P3 marker. Keep the live
    // thermal view completely clear while it is hidden.
    return;
  }

  // Movable protected card: the renderer does not paint underneath this region,
  // so temperatures and delta values remain solid instead of flashing.
  tft.fillRoundRect(cardX, cardY, PROBE_CARD_W, PROBE_CARD_H, 6, CARD);
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, CARD);
  tft.setCursor(cardX + 7, cardY + 5);
  tft.print("INSPECTION "); tft.print(activeCount); tft.print("/3");

  int tx = cardX + 7;
  for (uint8_t i = 0; i < 3; ++i) {
    tft.setCursor(tx, cardY + 18);
    tft.setTextColor(enabled[i] ? pointColours[i] : ILI9341_DARKGREY, CARD);
    tft.print("P"); tft.print(i + 1); tft.print(" ");
    if (enabled[i]) tft.print(temperatures[i], 1);
    else tft.print("--.-");
    tx += 49;
  }

  tft.setCursor(cardX + 7, cardY + 31);
  if (enabled[0] && enabled[1]) {
    tft.setTextColor(ILI9341_YELLOW, CARD);
    const float d12 = temperatures[1] - temperatures[0];
    tft.print("D12 "); if (d12 >= 0.0f) tft.print("+"); tft.print(d12, 1); tft.print("C");
  } else {
    tft.setTextColor(ILI9341_LIGHTGREY, CARD);
    tft.print("TAP IMAGE FOR NEXT POINT");
  }

  if (enabled[0] && enabled[2]) {
    tft.setCursor(cardX + 80, cardY + 31);
    tft.setTextColor(ILI9341_MAGENTA, CARD);
    const float d13 = temperatures[2] - temperatures[0];
    tft.print("D13 "); if (d13 >= 0.0f) tft.print("+"); tft.print(d13, 1); tft.print("C");
  }
}

bool UI::sensorPointToScreen(float sensorX, float sensorY, bool mirrorImage,
                             uint8_t zoomLevel, int& screenX, int& screenY)
{
  float nx = sensorX / static_cast<float>(SENSOR_WIDTH - 1);
  float ny = sensorY / static_cast<float>(SENSOR_HEIGHT - 1);
  if (mirrorImage) nx = 1.0f - nx;
  const float zoom = static_cast<float>(zoomLevel);
  nx = (nx - 0.5f) * zoom + 0.5f;
  ny = (ny - 0.5f) * zoom + 0.5f;
  if (nx < 0 || nx > 1 || ny < 0 || ny > 1) return false;
  screenX = IMAGE_X + static_cast<int>(nx * (IMAGE_WIDTH - 1));
  screenY = IMAGE_Y + static_cast<int>(ny * (IMAGE_HEIGHT - 1));
  return true;
}

bool UI::sensorPixelToScreen(int sensorPixel, bool mirrorImage, uint8_t zoomLevel,
                             int& screenX, int& screenY)
{
  float nx = static_cast<float>(sensorPixel % SENSOR_WIDTH) / (SENSOR_WIDTH - 1);
  float ny = static_cast<float>(sensorPixel / SENSOR_WIDTH) / (SENSOR_HEIGHT - 1);
  if (mirrorImage) nx = 1.0f - nx;
  const float zoom = static_cast<float>(zoomLevel);
  nx = (nx - 0.5f) * zoom + 0.5f;
  ny = (ny - 0.5f) * zoom + 0.5f;
  if (nx < 0 || nx > 1 || ny < 0 || ny > 1) return false;
  screenX = IMAGE_X + static_cast<int>(nx * (IMAGE_WIDTH - 1));
  screenY = IMAGE_Y + static_cast<int>(ny * (IMAGE_HEIGHT - 1));
  return true;
}

void UI::drawHotspotOnly(Adafruit_ILI9341& tft, float hotSensorX, float hotSensorY,
                         float hotTemperature, bool mirrorImage, uint8_t zoomLevel)
{
  // Full-screen tracker uses the same mirror + zoom transform as the full-screen renderer.
  float nx = hotSensorX / static_cast<float>(SENSOR_WIDTH - 1);
  float ny = hotSensorY / static_cast<float>(SENSOR_HEIGHT - 1);
  if (mirrorImage) nx = 1.0f - nx;
  const float zoom = static_cast<float>(zoomLevel);
  nx = (nx - 0.5f) * zoom + 0.5f;
  ny = (ny - 0.5f) * zoom + 0.5f;
  if (nx < 0.0f || nx > 1.0f || ny < 0.0f || ny > 1.0f) return;
  const int x = static_cast<int>(nx * (SCREEN_WIDTH - 1));
  const int y = static_cast<int>(ny * (SCREEN_HEIGHT - 1));
  const int boxHalf = 9;
  tft.drawRect(x - boxHalf - 1, y - boxHalf - 1, boxHalf * 2 + 3, boxHalf * 2 + 3, ILI9341_BLACK);
  tft.drawRect(x - boxHalf, y - boxHalf, boxHalf * 2 + 1, boxHalf * 2 + 1, ILI9341_RED);
  tft.drawFastHLine(x - 4, y, 9, ILI9341_RED);
  tft.drawFastVLine(x, y - 4, 9, ILI9341_RED);
  // Numeric hotspot value is deliberately not painted beside the moving marker.
  // A moving text tag was erased by the next thermal frame and was the main source
  // of visible temperature-number flicker. MAX is shown in a protected fixed UI area.
  (void)hotTemperature;
}

void UI::drawSmartHotspot(Adafruit_ILI9341& tft, float hotSensorX, float hotSensorY,
                          float hotTemperature, int coldestPixel,
                          bool mirrorImage, uint8_t zoomLevel)
{
  int x, y;
  if (sensorPointToScreen(hotSensorX, hotSensorY, mirrorImage, zoomLevel, x, y)) {
    // Stable tracking box with a compact temperature tag.
    const int boxHalf = 9;
    tft.drawRect(x - boxHalf - 1, y - boxHalf - 1, boxHalf * 2 + 3, boxHalf * 2 + 3, ILI9341_BLACK);
    tft.drawRect(x - boxHalf, y - boxHalf, boxHalf * 2 + 1, boxHalf * 2 + 1, ILI9341_RED);
    tft.drawFastHLine(x - 4, y, 9, ILI9341_RED);
    tft.drawFastVLine(x, y - 4, 9, ILI9341_RED);

    // Keep the tracker itself live, but keep changing numbers in protected cards.
    // This prevents the thermal renderer and text renderer fighting each other.
    (void)hotTemperature;
  }

  if (sensorPixelToScreen(coldestPixel, mirrorImage, zoomLevel, x, y)) {
    tft.drawCircle(x, y, 6, ILI9341_BLACK);
    tft.drawCircle(x, y, 5, ILI9341_CYAN);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_CYAN, ILI9341_BLACK);
    tft.setCursor(constrain(x + 8, 0, SCREEN_WIDTH - 7),
                  constrain(y - 4, IMAGE_Y, IMAGE_Y + IMAGE_HEIGHT - 8));
    tft.print("L");
  }
}

void UI::updateOverlay(Adafruit_ILI9341& tft, float spot, float minimum, float maximum,
                       float fps, bool freezeFrame, bool isothermEnabled,
                       float isothermThreshold, int centreX, int centreY,
                       int statsX, int statsY, bool fullScreen)
{
  if (fullScreen) return;

  const int spot10 = static_cast<int>(lroundf(spot * 10.0f));
  const int min10 = static_cast<int>(lroundf(minimum * 10.0f));
  const int max10 = static_cast<int>(lroundf(maximum * 10.0f));
  const int fpsInt = static_cast<int>(lroundf(fps));
  const bool moved = !overlayCacheValid || centreX != cachedCentreX || centreY != cachedCentreY ||
                     statsX != cachedStatsX || statsY != cachedStatsY;

  if (moved) {
    // Draw card shells once. The renderer protects these rectangles, so there is
    // no reason to repaint the entire cards every 250 ms.
    tft.fillRoundRect(centreX, centreY, CENTRE_CARD_W, CENTRE_CARD_H, 6, CARD);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_LIGHTGREY, CARD);
    tft.setCursor(centreX + 6, centreY + 4); tft.print("CENTRE");

    tft.fillRoundRect(statsX, statsY, STATS_CARD_W, STATS_CARD_H, 6, CARD);
  }

  if (moved || spot10 != cachedSpot10) {
    tft.fillRect(centreX + 4, centreY + 14, CENTRE_CARD_W - 8, 15, CARD);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_WHITE, CARD);
    tft.setCursor(centreX + 6, centreY + 17); tft.print(spot, 1); tft.print(" C");
  }

  if (moved || max10 != cachedMax10) {
    tft.fillRect(statsX + 3, statsY + 2, STATS_CARD_W - 6, 12, CARD);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_RED, CARD);
    tft.setCursor(statsX + 5, statsY + 4); tft.print("H "); tft.print(maximum, 1);
  }

  if (moved || min10 != cachedMin10 || fpsInt != cachedFps || freezeFrame != cachedFreeze) {
    tft.fillRect(statsX + 3, statsY + 14, STATS_CARD_W - 6, 15, CARD);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_CYAN, CARD);
    tft.setCursor(statsX + 5, statsY + 16); tft.print("L "); tft.print(minimum, 1);
    tft.setTextColor(ILI9341_LIGHTGREY, CARD);
    tft.setCursor(statsX + 52, statsY + 16);
    if (freezeFrame) tft.print("HOLD"); else { tft.print(fpsInt); tft.print("F"); }
  }

  cachedCentreX = centreX; cachedCentreY = centreY;
  cachedStatsX = statsX; cachedStatsY = statsY;
  cachedSpot10 = spot10; cachedMin10 = min10; cachedMax10 = max10;
  cachedFps = fpsInt; cachedFreeze = freezeFrame;
  overlayCacheValid = true;

  (void)isothermEnabled;
  (void)isothermThreshold;
}


