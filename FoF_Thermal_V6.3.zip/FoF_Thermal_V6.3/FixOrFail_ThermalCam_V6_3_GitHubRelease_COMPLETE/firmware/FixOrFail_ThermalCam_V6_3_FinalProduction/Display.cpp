#include "Display.h"

#include "Palette.h"

Display::Display()
  : displaySPI(FSPI),
    screen(
      &displaySPI,
      TFT_DC,
      TFT_CS,
      TFT_RST
    )
{
}

void Display::begin()
{
  pinMode(TFT_BL, OUTPUT);
  digitalWrite(TFT_BL, HIGH);

  displaySPI.begin(
    TFT_SCLK,
    TFT_MISO,
    TFT_MOSI,
    TFT_CS
  );

  screen.begin();
  screen.setSPISpeed(TFT_SPI_HZ);
  screen.setRotation(1);
  screen.setTextWrap(false);
  screen.fillScreen(ILI9341_BLACK);
}

void Display::clear()
{
  screen.fillScreen(ILI9341_BLACK);
}

Adafruit_ILI9341& Display::tft()
{
  return screen;
}

SPIClass& Display::spi()
{
  return displaySPI;
}

void Display::setInspectionCardVisible(bool visible)
{
  inspectionCardVisible = visible;
}

void Display::setInspectionCardRect(int x, int y)
{
  inspectionCardX = constrain(x, 0, SCREEN_WIDTH - PROBE_CARD_W);
  inspectionCardY = constrain(y, HEADER_HEIGHT, SCREEN_HEIGHT - NAV_HEIGHT - PROBE_CARD_H);
}

void Display::setFullScreen(bool enabled)
{
  fullScreenEnabled = enabled;
}

void Display::setInfoCardRects(bool visible, int centreX, int centreY, int statsX, int statsY)
{
  infoCardsVisible = visible;
  centreCardX = centreX;
  centreCardY = centreY;
  statsCardX = statsX;
  statsCardY = statsY;
}

void Display::setTemperatureScaleReserved(bool reserved)
{
  temperatureScaleReserved = reserved;
}

void Display::setTopOverlayReserved(bool reserved)
{
  topOverlayReserved = reserved;
}


void Display::ensureInterpolationMap(
  int viewportWidth,
  int viewportHeight,
  bool mirrorImage,
  uint8_t zoomLevel
)
{
  if (cachedMapWidth == viewportWidth && cachedMapHeight == viewportHeight &&
      cachedMapMirror == mirrorImage && cachedMapZoom == zoomLevel) return;

  const float zoom = static_cast<float>(zoomLevel > 0 ? zoomLevel : 1);

  for (int x = 0; x < viewportWidth; ++x) {
    float nx = static_cast<float>(x) / static_cast<float>(max(1, viewportWidth - 1));
    if (zoomLevel > 1) nx = (nx - 0.5f) / zoom + 0.5f;
    nx = constrain(nx, 0.0f, 1.0f);
    if (mirrorImage) nx = 1.0f - nx;
    const float sx = nx * static_cast<float>(SENSOR_WIDTH - 1);
    const int x0 = constrain(static_cast<int>(sx), 0, SENSOR_WIDTH - 1);
    mapX0[x] = static_cast<uint8_t>(x0);
    mapX1[x] = static_cast<uint8_t>(min(x0 + 1, SENSOR_WIDTH - 1));
    mapXF[x] = sx - static_cast<float>(x0);
  }

  for (int y = 0; y < viewportHeight; ++y) {
    float ny = static_cast<float>(y) / static_cast<float>(max(1, viewportHeight - 1));
    if (zoomLevel > 1) ny = (ny - 0.5f) / zoom + 0.5f;
    ny = constrain(ny, 0.0f, 1.0f);
    const float sy = ny * static_cast<float>(SENSOR_HEIGHT - 1);
    const int y0 = constrain(static_cast<int>(sy), 0, SENSOR_HEIGHT - 1);
    mapY0[y] = static_cast<uint8_t>(y0);
    mapY1[y] = static_cast<uint8_t>(min(y0 + 1, SENSOR_HEIGHT - 1));
    mapYF[y] = sy - static_cast<float>(y0);
  }

  cachedMapWidth = viewportWidth;
  cachedMapHeight = viewportHeight;
  cachedMapMirror = mirrorImage;
  cachedMapZoom = zoomLevel;
}

inline float Display::interpolateMapped(const float* grid, int imageX, int imageY) const
{
  const int x0 = mapX0[imageX];
  const int x1 = mapX1[imageX];
  const int y0 = mapY0[imageY];
  const int y1 = mapY1[imageY];
  const float xf = mapXF[imageX];
  const float yf = mapYF[imageY];

  const float tl = grid[y0 * SENSOR_WIDTH + x0];
  const float tr = grid[y0 * SENSOR_WIDTH + x1];
  const float bl = grid[y1 * SENSOR_WIDTH + x0];
  const float br = grid[y1 * SENSOR_WIDTH + x1];
  const float top = tl + (tr - tl) * xf;
  const float bottom = bl + (br - bl) * xf;
  return top + (bottom - top) * yf;
}


void Display::buildV4QualityGrid(
  const float* sourceGrid,
  float displayMinimum,
  float displayMaximum
)
{
  if (!V4_QUALITY_ENGINE) {
    for (int i = 0; i < PIXEL_COUNT; ++i) v4QualityGrid[i] = sourceGrid[i];
    return;
  }

  const float sceneSpan = max(0.5f, displayMaximum - displayMinimum);
  const float edgeThreshold = constrain(
    sceneSpan * V4_SPATIAL_EDGE_RANGE_FACTOR,
    V4_SPATIAL_EDGE_THRESHOLD_MIN_C,
    V4_SPATIAL_EDGE_THRESHOLD_MAX_C
  );

  // Edge-preserving spatial denoise on the native 32x24 grid. Pixels across
  // a strong thermal boundary contribute very little, so edges stay crisp.
  for (int y = 0; y < SENSOR_HEIGHT; ++y) {
    for (int x = 0; x < SENSOR_WIDTH; ++x) {
      const int index = y * SENSOR_WIDTH + x;
      const float centre = sourceGrid[index];
      float sum = centre * 4.0f;
      float weightSum = 4.0f;

      for (int oy = -1; oy <= 1; ++oy) {
        for (int ox = -1; ox <= 1; ++ox) {
          if (ox == 0 && oy == 0) continue;
          const int nx = x + ox;
          const int ny = y + oy;
          if (nx < 0 || nx >= SENSOR_WIDTH || ny < 0 || ny >= SENSOR_HEIGHT) continue;

          const float neighbour = sourceGrid[ny * SENSOR_WIDTH + nx];
          const float difference = fabsf(neighbour - centre);
          const float geometryWeight = (ox == 0 || oy == 0) ? 2.0f : 1.0f;

          float thermalWeight;
          if (difference <= edgeThreshold * 0.45f) thermalWeight = 1.0f;
          else if (difference <= edgeThreshold) thermalWeight = 0.48f;
          else thermalWeight = 0.08f;

          const float weight = geometryWeight * thermalWeight;
          sum += neighbour * weight;
          weightSum += weight;
        }
      }
      v4SpatialGrid[index] = sum / weightSum;
    }
  }

  // Detail recovery plus motion-adaptive temporal stabilisation. Static areas
  // become very clean; moving hot objects receive mostly the current frame so
  // they do not leave long trails.
  for (int i = 0; i < PIXEL_COUNT; ++i) {
    const float source = sourceGrid[i];
    float detail = source - v4SpatialGrid[i];
    detail = constrain(detail, -V4_DETAIL_LIMIT_C, V4_DETAIL_LIMIT_C);
    const float enhanced = source + detail * V4_DETAIL_STRENGTH;

    if (!v4HistoryValid) {
      v4QualityGrid[i] = enhanced;
      v4HistoryGrid[i] = enhanced;
      continue;
    }

    const float motion = fabsf(enhanced - v4HistoryGrid[i]);
    float newWeight = V4_TEMPORAL_MEDIUM_WEIGHT;
    if (motion <= V4_TEMPORAL_STILL_DELTA_C) {
      newWeight = V4_TEMPORAL_STILL_WEIGHT;
    } else if (motion >= V4_TEMPORAL_MOTION_DELTA_C) {
      newWeight = V4_TEMPORAL_MOTION_WEIGHT;
    } else {
      const float position = (motion - V4_TEMPORAL_STILL_DELTA_C) /
        (V4_TEMPORAL_MOTION_DELTA_C - V4_TEMPORAL_STILL_DELTA_C);
      newWeight = V4_TEMPORAL_MEDIUM_WEIGHT +
        (V4_TEMPORAL_MOTION_WEIGHT - V4_TEMPORAL_MEDIUM_WEIGHT) * position;
    }

    const float stable = v4HistoryGrid[i] * (1.0f - newWeight) + enhanced * newWeight;
    v4QualityGrid[i] = stable;
    v4HistoryGrid[i] = stable;
  }
  v4HistoryValid = true;
}

void Display::buildEdgeAssistGrid(
  const float* sourceGrid,
  float displayMinimum,
  float displayMaximum
)
{
  // Lightweight display-only unsharp mask on the native 32x24 grid.
  // It improves visible thermal boundaries without changing the source grid,
  // measurements, statistics, filtering, tracking or UART data.
  for (int y = 0; y < SENSOR_HEIGHT; ++y) {
    for (int x = 0; x < SENSOR_WIDTH; ++x) {
      const int index = y * SENSOR_WIDTH + x;
      const float centre = sourceGrid[index];

      if (!DISPLAY_EDGE_ASSIST || x == 0 || y == 0 ||
          x == SENSOR_WIDTH - 1 || y == SENSOR_HEIGHT - 1) {
        edgeAssistGrid[index] = centre;
        continue;
      }

      const float neighbours =
        sourceGrid[index - 1] + sourceGrid[index + 1] +
        sourceGrid[index - SENSOR_WIDTH] + sourceGrid[index + SENSOR_WIDTH];
      const float localAverage = neighbours * 0.25f;
      float detail = centre - localAverage;
      detail = constrain(detail, -EDGE_ASSIST_LIMIT_C, EDGE_ASSIST_LIMIT_C);

      edgeAssistGrid[index] = constrain(
        centre + detail * EDGE_ASSIST_STRENGTH,
        displayMinimum,
        displayMaximum
      );
    }
  }
}

void Display::renderImage(
  const float* filteredGrid,
  float displayMinimum,
  float displayMaximum,
  bool mirrorImage,
  uint8_t zoomLevel,
  bool isothermEnabled,
  float isothermThreshold
)
{
  buildV4QualityGrid(filteredGrid, displayMinimum, displayMaximum);
  const float* qualitySource = V4_QUALITY_ENGINE ? v4QualityGrid : filteredGrid;
  buildEdgeAssistGrid(qualitySource, displayMinimum, displayMaximum);
  const float* displayGrid = DISPLAY_EDGE_ASSIST ? edgeAssistGrid : qualitySource;

  const int renderX = 0;
  const int renderY = fullScreenEnabled ? 0 : IMAGE_Y;
  const int renderWidth = (fullScreenEnabled && temperatureScaleReserved) ? SCALE_RAIL_X : SCREEN_WIDTH;
  const int renderHeight = fullScreenEnabled ? SCREEN_HEIGHT : IMAGE_HEIGHT;

  ensureInterpolationMap(renderWidth, renderHeight, mirrorImage, zoomLevel);
  screen.startWrite();

  for (int y = 0; y < renderHeight; y++) {
    if ((y % RENDER_YIELD_ROWS) == 0) yield();
    for (int x = 0; x < renderWidth; x++) {
      const float temperature = interpolateMapped(displayGrid, x, y);

      // Display-only S-curve contrast enhancement. The original temperature
      // remains untouched for spot, min/max and hotspot calculations.
      float colourTemperature = temperature;
      if (DISPLAY_CONTRAST_ENHANCEMENT && displayMaximum > displayMinimum) {
        const float range = displayMaximum - displayMinimum;
        float normalised = (temperature - displayMinimum) / range;
        normalised = constrain(normalised, 0.0f, 1.0f);

        // Sigmoid-like centre expansion improves useful detail while preserving
        // smooth gradients at both ends of the palette.
        const float centred = normalised * 2.0f - 1.0f;
        const float curved = 0.5f + 0.5f *
          (centred * (1.5f - 0.5f * centred * centred));
        const float enhanced = normalised +
          (curved - normalised) * DISPLAY_CONTRAST_STRENGTH;
        colourTemperature = displayMinimum +
          constrain(enhanced, 0.0f, 1.0f) * range;
      }

      // Static 4x4 ordered dither reduces RGB565/palette banding without
      // random noise or frame-to-frame sparkle.
      if (V4_ORDERED_DITHER && displayMaximum > displayMinimum) {
        static const uint8_t bayer4[16] = {
          0, 8, 2, 10,
          12, 4, 14, 6,
          3, 11, 1, 9,
          15, 7, 13, 5
        };
        const float range = displayMaximum - displayMinimum;
        const float quantStep = range / 255.0f;
        const float offset =
          (static_cast<float>(bayer4[(y & 3) * 4 + (x & 3)]) / 15.0f - 0.5f) *
          quantStep * V4_DITHER_STRENGTH;
        colourTemperature = constrain(
          colourTemperature + offset, displayMinimum, displayMaximum);
      }

      uint16_t colour =
        temperatureToColour(
          colourTemperature,
          displayMinimum,
          displayMaximum
        );

      if (isothermEnabled) {
        // V2.2 display-only hot isotherm: everything below the selected
        // threshold is greyscale, while qualifying hot areas are bright red.
        // The measured temperature grid and all statistics remain untouched.
        if (temperature >= isothermThreshold) {
          colour = ILI9341_RED;
        } else {
          colour = temperatureToGreyscale(
            colourTemperature,
            displayMinimum,
            displayMaximum
          );
        }
      }

      lineBuffer[x] = colour;
    }

    const int screenY = renderY + y;

    if (fullScreenEnabled && topOverlayReserved && screenY < QUICK_BAR_Y + QUICK_BUTTON_H + 4) {
      continue;
    }

    // V4.2: dynamic protected regions for movable compact cards.
    auto intersectsRow = [&](int rx, int ry, int rw, int rh) -> bool {
      return infoCardsVisible && screenY >= ry && screenY < ry + rh;
    };
    auto writeSpan = [&](int sx, int width) {
      if (width <= 0) return;
      screen.setAddrWindow(renderX + sx, screenY, width, 1);
      screen.writePixels(lineBuffer + sx, static_cast<uint32_t>(width), true);
    };

    if (infoCardsVisible &&
        (intersectsRow(centreCardX, centreCardY, CENTRE_CARD_W, CENTRE_CARD_H) ||
         intersectsRow(statsCardX, statsCardY, STATS_CARD_W, STATS_CARD_H))) {
      int segments[6] = {0, renderWidth, 0, 0, 0, 0};
      int cuts[4]; int cutCount = 0;
      if (intersectsRow(centreCardX, centreCardY, CENTRE_CARD_W, CENTRE_CARD_H)) {
        cuts[cutCount++] = constrain(centreCardX, 0, renderWidth);
        cuts[cutCount++] = constrain(centreCardX + CENTRE_CARD_W, 0, renderWidth);
      }
      if (intersectsRow(statsCardX, statsCardY, STATS_CARD_W, STATS_CARD_H)) {
        cuts[cutCount++] = constrain(statsCardX, 0, renderWidth);
        cuts[cutCount++] = constrain(statsCardX + STATS_CARD_W, 0, renderWidth);
      }
      // Draw visible spans outside protected card rectangles.
      for (int sx = 0; sx < renderWidth; ) {
        bool protectedPixel = false;
        int next = renderWidth;
        if (intersectsRow(centreCardX, centreCardY, CENTRE_CARD_W, CENTRE_CARD_H)) {
          if (sx >= centreCardX && sx < centreCardX + CENTRE_CARD_W) { protectedPixel = true; next = centreCardX + CENTRE_CARD_W; }
          else if (sx < centreCardX) next = min(next, centreCardX);
        }
        if (intersectsRow(statsCardX, statsCardY, STATS_CARD_W, STATS_CARD_H)) {
          if (sx >= statsCardX && sx < statsCardX + STATS_CARD_W) { protectedPixel = true; next = max(next == renderWidth ? 0 : next, statsCardX + STATS_CARD_W); }
          else if (sx < statsCardX) next = min(next, statsCardX);
        }
        next = constrain(next, sx + 1, renderWidth);
        if (!protectedPixel) writeSpan(sx, next - sx);
        sx = next;
      }
    } else if (!fullScreenEnabled && inspectionCardVisible &&
               screenY >= inspectionCardY &&
               screenY < inspectionCardY + PROBE_CARD_H) {
      const int protectedLeft = max(renderX, inspectionCardX);
      const int protectedRight = min(renderX + renderWidth, inspectionCardX + PROBE_CARD_W);
      if (protectedLeft > renderX) {
        writeSpan(0, protectedLeft - renderX);
      }
      if (protectedRight < renderX + renderWidth) {
        writeSpan(protectedRight - renderX, renderX + renderWidth - protectedRight);
      }
    } else {
      writeSpan(0, renderWidth);
    }
  }
  screen.endWrite();
}
