#include "Palette.h"

static uint16_t colourPalette[256];
static Adafruit_ILI9341* displayReference = nullptr;

static uint16_t makeColour(
  Adafruit_ILI9341& tft,
  int red,
  int green,
  int blue
)
{
  return tft.color565(
    constrain(red, 0, 255),
    constrain(green, 0, 255),
    constrain(blue, 0, 255)
  );
}

static void buildIronbow(Adafruit_ILI9341& tft)
{
  for (int index = 0; index < 256; index++) {
    const float value =
      index / 255.0f;

    float red = 0.0f;
    float green = 0.0f;
    float blue = 0.0f;

    if (value < 0.20f) {
      blue =
        (value / 0.20f) * 90.0f;
    }
    else if (value < 0.40f) {
      const float section =
        (value - 0.20f) / 0.20f;

      red = section * 130.0f;
      blue =
        90.0f + section * 100.0f;
    }
    else if (value < 0.60f) {
      const float section =
        (value - 0.40f) / 0.20f;

      red =
        130.0f + section * 125.0f;

      green =
        section * 25.0f;

      blue =
        190.0f - section * 190.0f;
    }
    else if (value < 0.80f) {
      const float section =
        (value - 0.60f) / 0.20f;

      red = 255.0f;

      green =
        25.0f + section * 190.0f;
    }
    else {
      const float section =
        (value - 0.80f) / 0.20f;

      red = 255.0f;

      green =
        215.0f + section * 40.0f;

      blue =
        section * 255.0f;
    }

    colourPalette[index] =
      makeColour(
        tft,
        static_cast<int>(red),
        static_cast<int>(green),
        static_cast<int>(blue)
      );
  }
}

static void buildRainbow(Adafruit_ILI9341& tft)
{
  for (int index = 0; index < 256; index++) {
    const float position =
      index / 255.0f;

    int red = 0;
    int green = 0;
    int blue = 0;

    if (position < 0.25f) {
      const float section =
        position / 0.25f;

      blue = 255;

      green =
        static_cast<int>(
          section * 255.0f
        );
    }
    else if (position < 0.50f) {
      const float section =
        (position - 0.25f) / 0.25f;

      blue =
        static_cast<int>(
          (1.0f - section) *
          255.0f
        );

      green = 255;
    }
    else if (position < 0.75f) {
      const float section =
        (position - 0.50f) / 0.25f;

      red =
        static_cast<int>(
          section * 255.0f
        );

      green = 255;
    }
    else {
      const float section =
        (position - 0.75f) / 0.25f;

      red = 255;

      green =
        static_cast<int>(
          (1.0f - section) *
          255.0f
        );
    }

    colourPalette[index] =
      makeColour(
        tft,
        red,
        green,
        blue
      );
  }
}

static void buildGreyscale(
  Adafruit_ILI9341& tft,
  bool inverted
)
{
  for (int index = 0; index < 256; index++) {
    const int level =
      inverted ? 255 - index : index;

    colourPalette[index] =
      makeColour(
        tft,
        level,
        level,
        level
      );
  }
}

static void buildLava(Adafruit_ILI9341& tft)
{
  for (int index = 0; index < 256; index++) {
    const float value =
      index / 255.0f;

    int red = 0;
    int green = 0;
    int blue = 0;

    if (value < 0.33f) {
      red =
        static_cast<int>(
          value / 0.33f *
          190.0f
        );
    }
    else if (value < 0.66f) {
      red = 255;

      green =
        static_cast<int>(
          (value - 0.33f) /
          0.33f *
          150.0f
        );
    }
    else {
      red = 255;

      green =
        150 +
        static_cast<int>(
          (value - 0.66f) /
          0.34f *
          105.0f
        );

      blue =
        static_cast<int>(
          (value - 0.66f) /
          0.34f *
          255.0f
        );
    }

    colourPalette[index] =
      makeColour(
        tft,
        red,
        green,
        blue
      );
  }
}

static void buildArctic(Adafruit_ILI9341& tft)
{
  for (int index = 0; index < 256; index++) {
    const float value =
      index / 255.0f;

    int red =
      static_cast<int>(
        value * 190.0f
      );

    int green =
      static_cast<int>(
        value * 255.0f
      );

    int blue =
      100 +
      static_cast<int>(
        value * 155.0f
      );

    colourPalette[index] =
      makeColour(
        tft,
        red,
        green,
        blue
      );
  }
}

void buildPalette(
  Adafruit_ILI9341& tft,
  PaletteMode mode
)
{
  displayReference = &tft;

  switch (mode) {
    case PALETTE_RAINBOW:
      buildRainbow(tft);
      break;

    case PALETTE_WHITE_HOT:
      buildGreyscale(tft, false);
      break;

    case PALETTE_BLACK_HOT:
      buildGreyscale(tft, true);
      break;

    case PALETTE_LAVA:
      buildLava(tft);
      break;

    case PALETTE_ARCTIC:
      buildArctic(tft);
      break;

    case PALETTE_IRONBOW:
    default:
      buildIronbow(tft);
      break;
  }
}

static int temperatureIndex(
  float temperature,
  float displayMinimum,
  float displayMaximum
)
{
  float range =
    displayMaximum - displayMinimum;

  if (range < 1.0f) {
    range = 1.0f;
  }

  float normalised =
    (temperature - displayMinimum) /
    range;

  normalised =
    constrain(normalised, 0.0f, 1.0f);

  return constrain(
    static_cast<int>(
      normalised * 255.0f
    ),
    0,
    255
  );
}

uint16_t temperatureToColour(
  float temperature,
  float displayMinimum,
  float displayMaximum
)
{
  return colourPalette[
    temperatureIndex(
      temperature,
      displayMinimum,
      displayMaximum
    )
  ];
}

uint16_t temperatureToGreyscale(
  float temperature,
  float displayMinimum,
  float displayMaximum
)
{
  const int level =
    temperatureIndex(
      temperature,
      displayMinimum,
      displayMaximum
    );

  if (displayReference == nullptr) {
    return 0;
  }

  return displayReference->color565(
    level,
    level,
    level
  );
}

uint16_t paletteColour(int index)
{
  return colourPalette[
    constrain(index, 0, 255)
  ];
}

PaletteMode nextPalette(PaletteMode mode)
{
  const int next =
    (
      static_cast<int>(mode) + 1
    ) %
    static_cast<int>(PALETTE_COUNT);

  return static_cast<PaletteMode>(next);
}

const char* paletteName(PaletteMode mode)
{
  switch (mode) {
    case PALETTE_RAINBOW:
      return "RAINBOW";

    case PALETTE_WHITE_HOT:
      return "WHITE";

    case PALETTE_BLACK_HOT:
      return "BLACK";

    case PALETTE_LAVA:
      return "LAVA";

    case PALETTE_ARCTIC:
      return "ARCTIC";

    case PALETTE_IRONBOW:
    default:
      return "IRON";
  }
}
