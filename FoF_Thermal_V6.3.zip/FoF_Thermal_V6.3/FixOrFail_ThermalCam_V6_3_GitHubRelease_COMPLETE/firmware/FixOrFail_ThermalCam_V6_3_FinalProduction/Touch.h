#pragma once
#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_ILI9341.h>
#include <XPT2046_Touchscreen.h>
#include "Config.h"

class TouchController {
public:
  TouchController();
  void begin(SPIClass& sharedSPI);
  bool readTap(int& screenX, int& screenY);
  bool readContinuous(int& screenX, int& screenY);
  bool hasSavedCalibration() const;
  bool runEightPointCalibration(Adafruit_ILI9341& tft);

private:
  XPT2046_Touchscreen touch;
  uint32_t lastTouchTime = 0;
  bool waitingForRelease = false;

  // Affine transform: screenX = ax*rawX + bx*rawY + cx
  //                   screenY = ay*rawX + by*rawY + cy
  float ax = 0.0f, bx = 0.0f, cx = 0.0f;
  float ay = 0.0f, by = 0.0f, cy = 0.0f;
  bool calibrated = false;

  bool readRawAverage(float& rawX, float& rawY);
  void setDefaultCalibration();
  bool loadCalibration();
  void saveCalibration();
  bool solveAffine(const float rawX[8], const float rawY[8],
                   const float screenX[8], const float screenY[8]);
  bool solve3x3(float matrix[3][3], float rhs[3], float out[3]);
};
