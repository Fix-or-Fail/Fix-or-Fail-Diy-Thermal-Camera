#pragma once

#include <Arduino.h>
#include <Adafruit_ILI9341.h>

enum PaletteMode {
  PALETTE_IRONBOW = 0,
  PALETTE_RAINBOW,
  PALETTE_WHITE_HOT,
  PALETTE_BLACK_HOT,
  PALETTE_LAVA,
  PALETTE_ARCTIC,
  PALETTE_COUNT
};

void buildPalette(
  Adafruit_ILI9341& tft,
  PaletteMode mode
);

uint16_t temperatureToColour(
  float temperature,
  float displayMinimum,
  float displayMaximum
);

uint16_t temperatureToGreyscale(
  float temperature,
  float displayMinimum,
  float displayMaximum
);

uint16_t paletteColour(int index);

PaletteMode nextPalette(PaletteMode mode);

const char* paletteName(PaletteMode mode);
