#include "Camera.h"

#include <math.h>

Camera::Camera()
  : serialPort(1)
{
}

void Camera::begin()
{
  // V6.2: the 4 KB queue reached 4048 bytes in the stress test. A 16 KB RX
  // queue keeps several complete 1544-byte frames buffered while the TFT is
  // busy, preventing UART overflow from turning into apparent sensor glitches.
  serialPort.setRxBufferSize(UART_RX_BUFFER_BYTES);

  serialPort.begin(
    115200,
    SERIAL_8N1,
    GY_RX_PIN,
    GY_TX_PIN
  );

  clearInput();
}

void Camera::clearInput()
{
  while (serialPort.available()) {
    serialPort.read();
  }
}

bool Camera::readFrame(uint32_t timeoutMs)
{
  const uint32_t queuedAtEntry = static_cast<uint32_t>(serialPort.available());
  if (queuedAtEntry > uartDiag.maxQueuedBytes) uartDiag.maxQueuedBytes = queuedAtEntry;

  const uint32_t searchStart = millis();
  bool firstHeaderByteFound = false;
  uint32_t skippedThisRead = 0;

  // Robust streaming parser: validate the two length bytes immediately after
  // a 0x5A 0x5A candidate. A false header is therefore rejected without
  // blindly consuming another complete 1544-byte packet.
  while (millis() - searchStart < timeoutMs) {
    while (serialPort.available()) {
      const uint8_t value = static_cast<uint8_t>(serialPort.read());

      if (!firstHeaderByteFound) {
        firstHeaderByteFound = (value == 0x5A);
        if (!firstHeaderByteFound) ++skippedThisRead;
        continue;
      }

      if (value != 0x5A) {
        ++skippedThisRead;
        firstHeaderByteFound = (value == 0x5A);
        continue;
      }

      // Header candidate found. Wait only for the length field first.
      frameBuffer[0] = 0x5A;
      frameBuffer[1] = 0x5A;
      size_t position = 2;
      const uint32_t lengthStart = millis();
      while (position < 4 && millis() - lengthStart < 80) {
        while (serialPort.available() && position < 4) {
          frameBuffer[position++] = static_cast<uint8_t>(serialPort.read());
        }
        if (position < 4) yield();
      }

      if (position != 4) {
        ++uartDiag.shortFrames;
        uartDiag.skippedBytes += skippedThisRead;
        if (skippedThisRead > uartDiag.maxSkippedBeforeHeader)
          uartDiag.maxSkippedBeforeHeader = skippedThisRead;
        return false;
      }

      const uint16_t payloadLength =
        static_cast<uint16_t>(frameBuffer[2]) |
        (static_cast<uint16_t>(frameBuffer[3]) << 8);

      if (payloadLength != EXPECTED_PAYLOAD_LENGTH) {
        ++uartDiag.badLengths;
        uartDiag.lastBadLength = payloadLength;
        // Stay in the same read call and keep searching. Preserve a possible
        // 0x5A at the end of the rejected length field as the first header byte.
        skippedThisRead += 2;
        firstHeaderByteFound = (frameBuffer[3] == 0x5A);
        continue;
      }

      uartDiag.skippedBytes += skippedThisRead;
      if (skippedThisRead > uartDiag.maxSkippedBeforeHeader)
        uartDiag.maxSkippedBeforeHeader = skippedThisRead;

      const uint32_t receiveStart = millis();
      while (position < FRAME_SIZE && millis() - receiveStart < UART_FRAME_RECEIVE_TIMEOUT_MS) {
        const uint32_t q = static_cast<uint32_t>(serialPort.available());
        if (q > uartDiag.maxQueuedBytes) uartDiag.maxQueuedBytes = q;
        while (serialPort.available() && position < FRAME_SIZE) {
          frameBuffer[position++] = static_cast<uint8_t>(serialPort.read());
        }
        if (position < FRAME_SIZE) yield();
      }

      if (position != FRAME_SIZE) {
        ++uartDiag.shortFrames;
        return false;
      }

      ++uartDiag.acceptedFrames;
      return true;
    }

    yield();
  }

  ++uartDiag.searchTimeouts;
  uartDiag.skippedBytes += skippedThisRead;
  if (skippedThisRead > uartDiag.maxSkippedBeforeHeader)
    uartDiag.maxSkippedBeforeHeader = skippedThisRead;
  return false;
}

bool Camera::decodeFrame(
  float* rawGrid,
  float* filteredGrid,
  bool firstFrame
)
{
  // First pass: count physically impossible samples. A small number is handled
  // as a bad sensor/UART pixel; a frame with widespread corruption is rejected.
  uint16_t invalidCount = 0;
  uint16_t firstInvalidPixel = 0;
  uint16_t firstInvalidRaw = 0;

  for (int pixel = 0; pixel < PIXEL_COUNT; ++pixel) {
    const size_t dataIndex = DATA_START + static_cast<size_t>(pixel) * 2;
    const uint16_t rawValue =
      static_cast<uint16_t>(frameBuffer[dataIndex]) |
      (static_cast<uint16_t>(frameBuffer[dataIndex + 1]) << 8);
    const float temperature = static_cast<float>(rawValue) / 100.0f;

    if (!isfinite(temperature) || temperature < MIN_VALID_TEMP_C || temperature > MAX_VALID_TEMP_C) {
      if (invalidCount == 0) {
        firstInvalidPixel = static_cast<uint16_t>(pixel);
        firstInvalidRaw = rawValue;
      }
      ++invalidCount;
    }
  }

  if (invalidCount > 0) {
    ++uartDiag.invalidTemperatureFrames;
    uartDiag.lastInvalidPixel = firstInvalidPixel;
    uartDiag.lastInvalidRaw = firstInvalidRaw;

    if (invalidCount > MAX_REPAIRABLE_INVALID_PIXELS) {
      ++uartDiag.corruptRejectedFrames;
      return false;
    }

    ++uartDiag.repairedFrames;
    uartDiag.repairedPixels += invalidCount;
  }

  auto rawTemperatureAt = [&](int pixel, bool& valid) -> float {
    if (pixel < 0 || pixel >= PIXEL_COUNT) {
      valid = false;
      return 0.0f;
    }
    const size_t idx = DATA_START + static_cast<size_t>(pixel) * 2;
    const uint16_t rv = static_cast<uint16_t>(frameBuffer[idx]) |
      (static_cast<uint16_t>(frameBuffer[idx + 1]) << 8);
    const float t = static_cast<float>(rv) / 100.0f;
    valid = isfinite(t) && t >= MIN_VALID_TEMP_C && t <= MAX_VALID_TEMP_C;
    return t;
  };

  for (int pixel = 0; pixel < PIXEL_COUNT; ++pixel) {
    bool valid = false;
    float temperature = rawTemperatureAt(pixel, valid);

    if (!valid) {
      if (!firstFrame) {
        // Best continuity: retain this pixel's last filtered measurement.
        temperature = filteredGrid[pixel];
      } else {
        // First-ever frame has no history. Use nearby valid thermal samples.
        float sum = 0.0f;
        int count = 0;
        const int x = pixel % SENSOR_WIDTH;
        const int y = pixel / SENSOR_WIDTH;
        const int neighbours[4] = {
          x > 0 ? pixel - 1 : -1,
          x + 1 < SENSOR_WIDTH ? pixel + 1 : -1,
          y > 0 ? pixel - SENSOR_WIDTH : -1,
          y + 1 < SENSOR_HEIGHT ? pixel + SENSOR_WIDTH : -1
        };
        for (int n : neighbours) {
          bool nv = false;
          const float nt = rawTemperatureAt(n, nv);
          if (nv) { sum += nt; ++count; }
        }
        temperature = count > 0 ? sum / static_cast<float>(count) : 20.0f;
      }
    }

    rawGrid[pixel] = temperature;
    if (firstFrame) {
      filteredGrid[pixel] = temperature;
    } else {
      filteredGrid[pixel] =
        filteredGrid[pixel] * PIXEL_OLD_WEIGHT +
        temperature * PIXEL_NEW_WEIGHT;
    }
  }

  return true;
}
