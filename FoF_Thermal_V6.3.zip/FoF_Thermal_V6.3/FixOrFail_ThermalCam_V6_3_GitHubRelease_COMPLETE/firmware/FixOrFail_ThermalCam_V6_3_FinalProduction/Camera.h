#pragma once

#include <Arduino.h>

#include "Config.h"

struct CameraUartDiagnostics {
  uint32_t acceptedFrames = 0;
  uint32_t searchTimeouts = 0;
  uint32_t shortFrames = 0;
  uint32_t badLengths = 0;
  uint32_t invalidTemperatureFrames = 0;
  uint32_t repairedFrames = 0;
  uint32_t repairedPixels = 0;
  uint32_t corruptRejectedFrames = 0;
  uint32_t skippedBytes = 0;
  uint32_t maxSkippedBeforeHeader = 0;
  uint32_t maxQueuedBytes = 0;
  uint16_t lastBadLength = 0;
  uint16_t lastInvalidPixel = 0;
  uint16_t lastInvalidRaw = 0;
};

class Camera {
public:
  Camera();

  void begin();
  void clearInput();

  bool readFrame(uint32_t timeoutMs);

  CameraUartDiagnostics uartDiagnostics() const { return uartDiag; }
  void resetUartDiagnostics() { uartDiag = CameraUartDiagnostics{}; }

  bool decodeFrame(
    float* rawGrid,
    float* filteredGrid,
    bool firstFrame
  );

private:
  HardwareSerial serialPort;
  uint8_t frameBuffer[FRAME_SIZE];
  CameraUartDiagnostics uartDiag;
};
