#include "Touch.h"
#include <Preferences.h>
#include <math.h>

namespace {
constexpr uint16_t CAL_BG = 0x18E3;
constexpr uint16_t CAL_CARD = 0x2945;
constexpr uint16_t CAL_ACCENT = ILI9341_ORANGE;
constexpr char PREF_NAMESPACE[] = "touchcal";
constexpr uint32_t CAL_MAGIC = 0x3843414CUL; // "8CAL"
}

TouchController::TouchController() : touch(TOUCH_CS, TOUCH_IRQ) {}

void TouchController::begin(SPIClass& sharedSPI)
{
  pinMode(TOUCH_CS, OUTPUT);
  digitalWrite(TOUCH_CS, HIGH);
  pinMode(TOUCH_IRQ, INPUT_PULLUP);
  touch.begin(sharedSPI);
  touch.setRotation(1);

  setDefaultCalibration();
  loadCalibration();
}

void TouchController::setDefaultCalibration()
{
  const float dx = static_cast<float>(TOUCH_X_RIGHT - TOUCH_X_LEFT);
  const float dy = static_cast<float>(TOUCH_Y_BOTTOM - TOUCH_Y_TOP);

  ax = (SCREEN_WIDTH - 1) / dx;
  bx = 0.0f;
  cx = -ax * TOUCH_X_LEFT;

  ay = 0.0f;
  by = (SCREEN_HEIGHT - 1) / dy;
  cy = -by * TOUCH_Y_TOP;
  calibrated = false;
}

bool TouchController::loadCalibration()
{
  Preferences prefs;
  if (!prefs.begin(PREF_NAMESPACE, true)) return false;
  const uint32_t magic = prefs.getUInt("magic", 0);
  if (magic != CAL_MAGIC) {
    prefs.end();
    return false;
  }

  ax = prefs.getFloat("ax", ax);
  bx = prefs.getFloat("bx", bx);
  cx = prefs.getFloat("cx", cx);
  ay = prefs.getFloat("ay", ay);
  by = prefs.getFloat("by", by);
  cy = prefs.getFloat("cy", cy);
  prefs.end();

  calibrated = isfinite(ax) && isfinite(bx) && isfinite(cx) &&
               isfinite(ay) && isfinite(by) && isfinite(cy);
  return calibrated;
}

void TouchController::saveCalibration()
{
  Preferences prefs;
  if (!prefs.begin(PREF_NAMESPACE, false)) return;
  prefs.putUInt("magic", CAL_MAGIC);
  prefs.putFloat("ax", ax);
  prefs.putFloat("bx", bx);
  prefs.putFloat("cx", cx);
  prefs.putFloat("ay", ay);
  prefs.putFloat("by", by);
  prefs.putFloat("cy", cy);
  prefs.end();
}

bool TouchController::hasSavedCalibration() const
{
  return calibrated;
}

bool TouchController::readRawAverage(float& rawX, float& rawY)
{
  const uint32_t waitStart = millis();
  while (!touch.touched()) {
    if (millis() - waitStart > 15000) return false;
    delay(5);
  }

  float sumX = 0.0f;
  float sumY = 0.0f;
  int samples = 0;
  const uint32_t sampleStart = millis();

  while (touch.touched() && millis() - sampleStart < 700) {
    TS_Point p = touch.getPoint();
    if (p.z >= TOUCH_MIN_PRESSURE) {
      sumX += p.x;
      sumY += p.y;
      ++samples;
    }
    delay(8);
  }

  const uint32_t releaseStart = millis();
  while (touch.touched() && millis() - releaseStart < 1200) delay(5);
  delay(120);

  if (samples < 4) return false;
  rawX = sumX / samples;
  rawY = sumY / samples;
  return true;
}

bool TouchController::solve3x3(float m[3][3], float rhs[3], float out[3])
{
  for (int pivot = 0; pivot < 3; ++pivot) {
    int best = pivot;
    for (int row = pivot + 1; row < 3; ++row) {
      if (fabsf(m[row][pivot]) > fabsf(m[best][pivot])) best = row;
    }
    if (fabsf(m[best][pivot]) < 1.0e-8f) return false;

    if (best != pivot) {
      for (int col = 0; col < 3; ++col) {
        const float tmp = m[pivot][col];
        m[pivot][col] = m[best][col];
        m[best][col] = tmp;
      }
      const float tmp = rhs[pivot];
      rhs[pivot] = rhs[best];
      rhs[best] = tmp;
    }

    const float div = m[pivot][pivot];
    for (int col = pivot; col < 3; ++col) m[pivot][col] /= div;
    rhs[pivot] /= div;

    for (int row = 0; row < 3; ++row) {
      if (row == pivot) continue;
      const float factor = m[row][pivot];
      for (int col = pivot; col < 3; ++col) m[row][col] -= factor * m[pivot][col];
      rhs[row] -= factor * rhs[pivot];
    }
  }

  out[0] = rhs[0];
  out[1] = rhs[1];
  out[2] = rhs[2];
  return true;
}

bool TouchController::solveAffine(const float rawX[8], const float rawY[8],
                                  const float screenX[8], const float screenY[8])
{
  float normal[3][3] = {};
  float rhsX[3] = {};
  float rhsY[3] = {};

  for (int i = 0; i < 8; ++i) {
    const float v[3] = {rawX[i], rawY[i], 1.0f};
    for (int r = 0; r < 3; ++r) {
      for (int c = 0; c < 3; ++c) normal[r][c] += v[r] * v[c];
      rhsX[r] += v[r] * screenX[i];
      rhsY[r] += v[r] * screenY[i];
    }
  }

  float matrixX[3][3];
  float matrixY[3][3];
  memcpy(matrixX, normal, sizeof(normal));
  memcpy(matrixY, normal, sizeof(normal));

  float resultX[3];
  float resultY[3];
  if (!solve3x3(matrixX, rhsX, resultX)) return false;
  if (!solve3x3(matrixY, rhsY, resultY)) return false;

  ax = resultX[0]; bx = resultX[1]; cx = resultX[2];
  ay = resultY[0]; by = resultY[1]; cy = resultY[2];

  float totalError = 0.0f;
  for (int i = 0; i < 8; ++i) {
    const float px = ax * rawX[i] + bx * rawY[i] + cx;
    const float py = ay * rawX[i] + by * rawY[i] + cy;
    const float ex = px - screenX[i];
    const float ey = py - screenY[i];
    totalError += sqrtf(ex * ex + ey * ey);
  }

  calibrated = isfinite(totalError) && (totalError / 8.0f) < 22.0f;
  return calibrated;
}

bool TouchController::runEightPointCalibration(Adafruit_ILI9341& tft)
{
  constexpr int margin = 20;
  const float targetX[8] = {
    margin, SCREEN_WIDTH / 2.0f, SCREEN_WIDTH - 1 - margin,
    SCREEN_WIDTH - 1 - margin, SCREEN_WIDTH - 1 - margin,
    SCREEN_WIDTH / 2.0f, margin, margin
  };
  const float targetY[8] = {
    margin, margin, margin,
    SCREEN_HEIGHT / 2.0f, SCREEN_HEIGHT - 1 - margin,
    SCREEN_HEIGHT - 1 - margin, SCREEN_HEIGHT - 1 - margin,
    SCREEN_HEIGHT / 2.0f
  };

  float rawX[8];
  float rawY[8];

  tft.fillScreen(CAL_BG);
  tft.setTextWrap(false);
  tft.setTextSize(2);
  tft.setTextColor(ILI9341_WHITE, CAL_BG);
  tft.setCursor(45, 82); tft.print("8-POINT TOUCH");
  tft.setTextColor(CAL_ACCENT, CAL_BG);
  tft.setCursor(64, 108); tft.print("CALIBRATION");
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_LIGHTGREY, CAL_BG);
  tft.setCursor(51, 143); tft.print("Tap each target accurately");
  delay(900);

  for (int i = 0; i < 8; ++i) {
    tft.fillScreen(CAL_BG);
    tft.fillRoundRect(35, 8, 250, 28, 8, CAL_CARD);
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_WHITE, CAL_CARD);
    tft.setCursor(75, 18); tft.print("TOUCH TARGET "); tft.print(i + 1); tft.print(" OF 8");

    const int x = static_cast<int>(targetX[i]);
    const int y = static_cast<int>(targetY[i]);
    tft.drawCircle(x, y, 11, ILI9341_WHITE);
    tft.drawCircle(x, y, 7, CAL_ACCENT);
    tft.drawFastHLine(x - 14, y, 29, CAL_ACCENT);
    tft.drawFastVLine(x, y - 14, 29, CAL_ACCENT);
    tft.fillCircle(x, y, 2, ILI9341_WHITE);

    if (!readRawAverage(rawX[i], rawY[i])) {
      tft.fillScreen(CAL_BG);
      tft.setTextSize(2);
      tft.setTextColor(ILI9341_RED, CAL_BG);
      tft.setCursor(74, 100); tft.print("TIMED OUT");
      tft.setTextSize(1);
      tft.setTextColor(ILI9341_WHITE, CAL_BG);
      tft.setCursor(72, 132); tft.print("Calibration not changed");
      delay(1200);
      return false;
    }
  }

  if (!solveAffine(rawX, rawY, targetX, targetY)) {
    tft.fillScreen(CAL_BG);
    tft.setTextSize(2);
    tft.setTextColor(ILI9341_RED, CAL_BG);
    tft.setCursor(48, 96); tft.print("CALIBRATION FAILED");
    tft.setTextSize(1);
    tft.setTextColor(ILI9341_WHITE, CAL_BG);
    tft.setCursor(61, 130); tft.print("Please try again carefully");
    delay(1500);
    return false;
  }

  saveCalibration();
  tft.fillScreen(CAL_BG);
  tft.fillRoundRect(50, 76, 220, 88, 12, CAL_CARD);
  tft.setTextSize(2);
  tft.setTextColor(ILI9341_GREEN, CAL_CARD);
  tft.setCursor(83, 94); tft.print("CALIBRATED");
  tft.setTextSize(1);
  tft.setTextColor(ILI9341_WHITE, CAL_CARD);
  tft.setCursor(76, 130); tft.print("Settings saved to memory");
  delay(1100);
  lastTouchTime = millis();
  return true;
}


bool TouchController::readContinuous(int& screenX, int& screenY)
{
  if (!touch.touched()) return false;
  TS_Point p = touch.getPoint();
  if (p.z < TOUCH_MIN_PRESSURE) return false;
  const float mappedX = ax * p.x + bx * p.y + cx;
  const float mappedY = ay * p.x + by * p.y + cy;
  screenX = constrain(static_cast<int>(lroundf(mappedX)), 0, SCREEN_WIDTH - 1);
  screenY = constrain(static_cast<int>(lroundf(mappedY)), 0, SCREEN_HEIGHT - 1);
  return true;
}

bool TouchController::readTap(int& screenX, int& screenY)
{
  // Register exactly one tap per physical press. The previous implementation
  // stopped waiting after 300 ms, so a long press could be seen as several taps.
  if (waitingForRelease) {
    if (touch.touched()) return false;
    waitingForRelease = false;
    lastTouchTime = millis();
    return false;
  }

  const uint32_t now = millis();
  if (now - lastTouchTime < TOUCH_DEBOUNCE_MS || !touch.touched()) return false;

  TS_Point p = touch.getPoint();
  if (p.z < TOUCH_MIN_PRESSURE) return false;

  const float mappedX = ax * p.x + bx * p.y + cx;
  const float mappedY = ay * p.x + by * p.y + cy;
  screenX = constrain(static_cast<int>(lroundf(mappedX)), 0, SCREEN_WIDTH - 1);
  screenY = constrain(static_cast<int>(lroundf(mappedY)), 0, SCREEN_HEIGHT - 1);

  waitingForRelease = true;
  return true;
}
