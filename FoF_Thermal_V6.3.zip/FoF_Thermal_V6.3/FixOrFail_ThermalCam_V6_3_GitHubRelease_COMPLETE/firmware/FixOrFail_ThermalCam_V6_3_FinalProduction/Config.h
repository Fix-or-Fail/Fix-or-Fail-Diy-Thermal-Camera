#pragma once
#include <Arduino.h>

// FIX OR FAIL THERMAL CAMERA V6.3 FINAL PRODUCTION
// ESP32-S3 N16R8 + GY-MCU90640 UART + ILI9341 + XPT2046

constexpr int TFT_MISO = 12;
constexpr int TFT_MOSI = 11;
constexpr int TFT_SCLK = 13;
constexpr int TFT_CS   = 10;
constexpr int TFT_DC   = 18;
constexpr int TFT_RST  = 14;
constexpr int TFT_BL   = 17;
constexpr uint32_t TFT_SPI_HZ = 40000000UL;  // ILI9341 on ESP32-S3: fast, stable production target

constexpr int TOUCH_CS  = 9;
constexpr int TOUCH_IRQ = 16;
constexpr int TOUCH_X_LEFT   = 470;
constexpr int TOUCH_X_RIGHT  = 3700;
constexpr int TOUCH_Y_TOP    = 3550;
constexpr int TOUCH_Y_BOTTOM = 380;
constexpr uint16_t TOUCH_MIN_PRESSURE = 250;
constexpr uint32_t TOUCH_DEBOUNCE_MS = 180;

constexpr int GY_RX_PIN = 44;
constexpr int GY_TX_PIN = 43;

constexpr int SENSOR_WIDTH = 32;
constexpr int SENSOR_HEIGHT = 24;
constexpr int PIXEL_COUNT = SENSOR_WIDTH * SENSOR_HEIGHT;
constexpr size_t FRAME_SIZE = 1544;
constexpr size_t DATA_START = 4;
constexpr uint16_t EXPECTED_PAYLOAD_LENGTH = 1538;
// V6.2 UART production-stability settings.
// The stress test showed the old 4096-byte queue reaching 4048 bytes, so use
// a much deeper queue and keep enough headroom for rendering/UI bursts.
constexpr size_t UART_RX_BUFFER_BYTES = 16384;
constexpr uint8_t MAX_REPAIRABLE_INVALID_PIXELS = 3;
constexpr uint32_t UART_FRAME_RECEIVE_TIMEOUT_MS = 420;


constexpr int SCREEN_WIDTH = 320;
constexpr int SCREEN_HEIGHT = 240;
constexpr int HEADER_HEIGHT = 24;
constexpr int NAV_HEIGHT = 0;
constexpr int IMAGE_X = 0;
constexpr int IMAGE_Y = HEADER_HEIGHT;
constexpr int IMAGE_WIDTH = SCREEN_WIDTH;
constexpr int IMAGE_HEIGHT = SCREEN_HEIGHT - HEADER_HEIGHT - NAV_HEIGHT;

constexpr float PIXEL_NEW_WEIGHT = 0.52f;
constexpr float PIXEL_OLD_WEIGHT = 0.48f;
constexpr float RANGE_RESPONSE = 0.10f;
constexpr float RANGE_ATTACK_RESPONSE = 0.38f;
constexpr float RANGE_DEADBAND_C = 0.12f;
constexpr float ELECTRONICS_RANGE_RESPONSE = 0.15f;
constexpr float RANGE_MARGIN_C = 0.4f;
constexpr float MINIMUM_RANGE_SPAN_C = 3.0f;
constexpr float ELECTRONICS_MIN_SPAN_C = 5.0f;
constexpr float ELECTRONICS_MAX_SPAN_C = 28.0f;
constexpr float MIN_VALID_TEMP_C = -40.0f;
constexpr float MAX_VALID_TEMP_C = 300.0f;
constexpr uint32_t UI_UPDATE_INTERVAL_MS = 250;
constexpr float OVERLAY_TEMP_REDRAW_STEP_C = 0.1f;
constexpr float OVERLAY_FPS_REDRAW_STEP = 1.0f;
constexpr float TRACK_POSITION_RESPONSE = 0.35f;
constexpr float TRACK_SWITCH_ADVANTAGE_C = 0.35f;

// Lightweight display-only contrast enhancement.
// This does not alter sensor temperatures, statistics, filtering or tracking.
constexpr bool DISPLAY_CONTRAST_ENHANCEMENT = true;
constexpr float DISPLAY_CONTRAST_STRENGTH = 0.68f;
constexpr float DISPLAY_LOW_PERCENTILE = 0.02f;
constexpr float DISPLAY_HIGH_PERCENTILE = 0.98f;

// Touch measurement probe overlay.
constexpr int PROBE_CARD_X = 7;
constexpr int PROBE_CARD_Y = 78;
constexpr int PROBE_CARD_W = 154;
constexpr int PROBE_CARD_H = 44;

// V1.2 display-only edge assist. Applied to a private copy of the 32x24
// temperature grid, so measured temperatures and the thermal engine remain unchanged.
constexpr bool DISPLAY_EDGE_ASSIST = true;
constexpr float EDGE_ASSIST_STRENGTH = 0.72f;
constexpr float EDGE_ASSIST_LIMIT_C = 1.20f;

// V3.0 retained isotherm highlight settings (display only).
constexpr float ISOTHERM_STEP_C = 1.0f;
constexpr float ISOTHERM_MIN_C = -40.0f;
constexpr float ISOTHERM_MAX_C = 300.0f;

// V4.0 Pro Imaging Engine - display-only quality processing.
// None of these settings modify measured temperatures or statistics.
constexpr bool V4_QUALITY_ENGINE = true;
constexpr float V4_SPATIAL_EDGE_THRESHOLD_MIN_C = 0.35f;
constexpr float V4_SPATIAL_EDGE_THRESHOLD_MAX_C = 1.60f;
constexpr float V4_SPATIAL_EDGE_RANGE_FACTOR = 0.050f;
constexpr float V4_DETAIL_STRENGTH = 0.42f;
constexpr float V4_DETAIL_LIMIT_C = 0.85f;
constexpr float V4_TEMPORAL_STILL_WEIGHT = 0.30f;
constexpr float V4_TEMPORAL_MEDIUM_WEIGHT = 0.55f;
constexpr float V4_TEMPORAL_MOTION_WEIGHT = 0.90f;
constexpr float V4_TEMPORAL_STILL_DELTA_C = 0.18f;
constexpr float V4_TEMPORAL_MOTION_DELTA_C = 1.20f;
constexpr bool V4_ORDERED_DITHER = true;
constexpr float V4_DITHER_STRENGTH = 0.28f;

// V4.2 production behaviour.
constexpr uint32_t SENSOR_READ_SLICE_MS = 350;
constexpr uint8_t SENSOR_RESYNC_FAILURES = 5;
constexpr uint8_t SENSOR_OFFLINE_FAILURES = 3;
constexpr uint32_t SENSOR_STATUS_REFRESH_MS = 500;

// V4.2 compact movable temperature cards.
constexpr int CENTRE_CARD_W = 74;
constexpr int CENTRE_CARD_H = 32;
constexpr int STATS_CARD_W = 86;
constexpr int STATS_CARD_H = 32;
constexpr uint32_t CARD_LONG_PRESS_MS = 500;
constexpr uint32_t CARD_DRAG_UPDATE_MS = 40;
constexpr int FULLSCREEN_BUTTON_X = 194;
constexpr int FULLSCREEN_BUTTON_Y = 3;
constexpr int FULLSCREEN_BUTTON_W = 43;
constexpr int FULLSCREEN_BUTTON_H = 18;

// Production reliability: yield periodically during long full-screen renders.
constexpr int RENDER_YIELD_ROWS = 24;

// V5.1 production UI polish.
constexpr bool DEFAULT_START_FULLSCREEN = false;
constexpr bool DEFAULT_CLEAN_MODE = false;
constexpr bool DEFAULT_TEMPERATURE_SCALE = true;
constexpr uint32_t FULLSCREEN_CONTROLS_TIMEOUT_MS = 4000;
constexpr int SCALE_RAIL_X = 282;  // renderer stops here so scale + labels never get erased
constexpr int SCALE_X = 301;
constexpr int SCALE_Y = 42;
constexpr int SCALE_W = 10;
constexpr int SCALE_H = 150;
constexpr int CLEAN_CARD_X = 8;
constexpr int CLEAN_CARD_Y = 8;
constexpr int CLEAN_CARD_W = CENTRE_CARD_W;
constexpr int CLEAN_CARD_H = CENTRE_CARD_H;
constexpr int QUICK_BAR_Y = 4;
constexpr int QUICK_BUTTON_H = 22;
constexpr int QUICK_BUTTON_GAP = 3;
