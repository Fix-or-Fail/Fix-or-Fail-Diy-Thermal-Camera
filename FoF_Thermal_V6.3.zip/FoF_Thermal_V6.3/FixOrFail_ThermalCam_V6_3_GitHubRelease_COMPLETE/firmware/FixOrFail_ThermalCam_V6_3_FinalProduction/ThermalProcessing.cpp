#include "ThermalProcessing.h"
#include <math.h>

float ThermalProcessing::neighbourhoodAverage(
  const float* grid, int centreX, int centreY)
{
  float sum = 0.0f;
  int count = 0;
  for (int yo = -1; yo <= 1; ++yo) {
    for (int xo = -1; xo <= 1; ++xo) {
      const int x = centreX + xo;
      const int y = centreY + yo;
      if (x >= 0 && x < SENSOR_WIDTH && y >= 0 && y < SENSOR_HEIGHT) {
        sum += grid[y * SENSOR_WIDTH + x];
        ++count;
      }
    }
  }
  return count ? sum / static_cast<float>(count) : 0.0f;
}

void ThermalProcessing::calculateStats(const float* grid, ThermalStats& stats)
{
  float minimum = 999.0f;
  float maximum = -999.0f;
  float total = 0.0f;
  int minPixel = 0;
  int maxPixel = 0;

  for (int pixel = 0; pixel < PIXEL_COUNT; ++pixel) {
    const float value = grid[pixel];
    total += value;
    if (value < minimum) { minimum = value; minPixel = pixel; }
    if (value > maximum) { maximum = value; maxPixel = pixel; }
  }

  stats.minimum = minimum;
  stats.maximum = maximum;
  stats.average = total / static_cast<float>(PIXEL_COUNT);
  stats.delta = maximum - minimum;
  stats.hottestPixel = maxPixel;
  stats.coldestPixel = minPixel;

  stats.spot = (
    grid[11 * SENSOR_WIDTH + 15] +
    grid[11 * SENSOR_WIDTH + 16] +
    grid[12 * SENSOR_WIDTH + 15] +
    grid[12 * SENSOR_WIDTH + 16]) * 0.25f;
}

void ThermalProcessing::updateStableExtremes(
  const float* grid, ThermalStats& stats, bool firstFrame)
{
  float bestHot = -999.0f;
  float bestCold = 999.0f;
  int bestHotX = 0, bestHotY = 0;
  int bestColdX = 0, bestColdY = 0;

  // Work on the 32x24 sensor grid only: inexpensive and noise resistant.
  for (int y = 0; y < SENSOR_HEIGHT; ++y) {
    for (int x = 0; x < SENSOR_WIDTH; ++x) {
      const float region = neighbourhoodAverage(grid, x, y);
      if (region > bestHot) { bestHot = region; bestHotX = x; bestHotY = y; }
      if (region < bestCold) { bestCold = region; bestColdX = x; bestColdY = y; }
    }
  }

  if (firstFrame) {
    trackedHotX = bestHotX;
    trackedHotY = bestHotY;
    trackedColdX = bestColdX;
    trackedColdY = bestColdY;
  } else {
    const int currentHotX = constrain(static_cast<int>(lroundf(trackedHotX)), 0, SENSOR_WIDTH - 1);
    const int currentHotY = constrain(static_cast<int>(lroundf(trackedHotY)), 0, SENSOR_HEIGHT - 1);
    const float currentHot = neighbourhoodAverage(grid, currentHotX, currentHotY);

    if (bestHot > currentHot + TRACK_SWITCH_ADVANTAGE_C) {
      trackedHotX += (bestHotX - trackedHotX) * TRACK_POSITION_RESPONSE;
      trackedHotY += (bestHotY - trackedHotY) * TRACK_POSITION_RESPONSE;
    }

    const int currentColdX = constrain(static_cast<int>(lroundf(trackedColdX)), 0, SENSOR_WIDTH - 1);
    const int currentColdY = constrain(static_cast<int>(lroundf(trackedColdY)), 0, SENSOR_HEIGHT - 1);
    const float currentCold = neighbourhoodAverage(grid, currentColdX, currentColdY);

    if (bestCold < currentCold - TRACK_SWITCH_ADVANTAGE_C) {
      trackedColdX += (bestColdX - trackedColdX) * TRACK_POSITION_RESPONSE;
      trackedColdY += (bestColdY - trackedColdY) * TRACK_POSITION_RESPONSE;
    }
  }

  const int hotX = constrain(static_cast<int>(lroundf(trackedHotX)), 0, SENSOR_WIDTH - 1);
  const int hotY = constrain(static_cast<int>(lroundf(trackedHotY)), 0, SENSOR_HEIGHT - 1);
  const int coldX = constrain(static_cast<int>(lroundf(trackedColdX)), 0, SENSOR_WIDTH - 1);
  const int coldY = constrain(static_cast<int>(lroundf(trackedColdY)), 0, SENSOR_HEIGHT - 1);

  stats.hottestPixel = hotY * SENSOR_WIDTH + hotX;
  stats.coldestPixel = coldY * SENSOR_WIDTH + coldX;
}
