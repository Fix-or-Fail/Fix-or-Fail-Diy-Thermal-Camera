#pragma once
#include <Arduino.h>
#include <Adafruit_ILI9341.h>
#include "Config.h"
#include "Palette.h"

class UI {
public:
  void showBootScreen(Adafruit_ILI9341& tft);
  void showBootStatus(Adafruit_ILI9341& tft, const char* status, bool ready = false);
  void updateSensorStatus(Adafruit_ILI9341& tft, bool online);
  void drawHomeChrome(Adafruit_ILI9341& tft, PaletteMode paletteMode,
                      bool freezeFrame, bool autoRange, uint8_t zoomLevel, bool fullScreen);
  void drawFullScreenControls(Adafruit_ILI9341& tft, bool freezeFrame,
                              bool autoRange, bool cleanMode);
  void drawTemperatureScale(Adafruit_ILI9341& tft, float minimum, float maximum);
  void drawCleanOverlay(Adafruit_ILI9341& tft, float spot, float hotTemperature);
  void drawMenu(Adafruit_ILI9341& tft, bool electronicsMode, bool mirrorImage,
                bool minMaxHold, bool isothermEnabled, float isothermThreshold);
  void drawSystemMenu(Adafruit_ILI9341& tft, bool cleanMode, bool startFullScreen,
                      bool temperatureScaleEnabled, bool resetArmed);
  void closeMenu(Adafruit_ILI9341& tft);
  void showDiagnostics(Adafruit_ILI9341& tft, float fps, uint32_t freeHeap,
                       uint32_t rejectedFrames, float rangeMinimum,
                       float rangeMaximum, float spot, float minimum,
                       float maximum, PaletteMode paletteMode, uint8_t zoomLevel);
  void showAbout(Adafruit_ILI9341& tft, bool sensorOnline, bool touchCalibrated,
                 uint32_t uptimeSeconds);
  void drawCrosshair(Adafruit_ILI9341& tft);
  void drawMeasurementPoints(Adafruit_ILI9341& tft, const bool enabled[3],
                             const int screenX[3], const int screenY[3],
                             const float temperatures[3], int cardX, int cardY,
                             bool cardVisible);
  void drawHotspotOnly(Adafruit_ILI9341& tft, float hotSensorX, float hotSensorY,
                       float hotTemperature, bool mirrorImage, uint8_t zoomLevel);
  void drawSmartHotspot(Adafruit_ILI9341& tft, float hotSensorX, float hotSensorY,
                        float hotTemperature, int coldestPixel,
                        bool mirrorImage, uint8_t zoomLevel);
  void invalidateDynamicOverlays();
  void updateOverlay(Adafruit_ILI9341& tft, float spot, float minimum, float maximum,
                     float fps, bool freezeFrame, bool isothermEnabled,
                     float isothermThreshold, int centreX, int centreY,
                     int statsX, int statsY, bool fullScreen);
private:
  bool menuVisible = false;
  bool overlayCacheValid = false;
  bool scaleCacheValid = false;
  bool cleanCacheValid = false;
  bool sensorCacheValid = false;
  bool cachedSensorOnline = false;
  int cachedCentreX = -1, cachedCentreY = -1;
  int cachedStatsX = -1, cachedStatsY = -1;
  int cachedSpot10 = 0, cachedMin10 = 0, cachedMax10 = 0;
  int cachedFps = -999;
  bool cachedFreeze = false;
  int cachedScaleMin = 0, cachedScaleMax = 0;
  int cachedCleanSpot10 = 0;
  bool sensorPointToScreen(float sensorX, float sensorY, bool mirrorImage,
                           uint8_t zoomLevel, int& screenX, int& screenY);
  bool sensorPixelToScreen(int sensorPixel, bool mirrorImage, uint8_t zoomLevel,
                           int& screenX, int& screenY);
  void navButton(Adafruit_ILI9341& tft, int index, const char* label, bool active);
  void menuRow(Adafruit_ILI9341& tft, int row, const char* label, bool enabled);
  void isothermRow(Adafruit_ILI9341& tft, int row, bool enabled, float threshold);
  void quickButton(Adafruit_ILI9341& tft, int index, const char* label, bool active);
};
