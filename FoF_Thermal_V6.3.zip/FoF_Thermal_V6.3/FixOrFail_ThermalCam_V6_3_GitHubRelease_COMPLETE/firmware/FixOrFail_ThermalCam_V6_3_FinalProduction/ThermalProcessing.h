#pragma once
#include <Arduino.h>
#include "Config.h"

struct ThermalStats {
  float minimum = 0.0f;
  float maximum = 0.0f;
  float average = 0.0f;
  float spot = 0.0f;
  float delta = 0.0f;
  int hottestPixel = 0;
  int coldestPixel = 0;
};

class ThermalProcessing {
public:
  void calculateStats(const float* grid, ThermalStats& stats);
  void updateStableExtremes(const float* grid, ThermalStats& stats, bool firstFrame);

private:
  float neighbourhoodAverage(const float* grid, int centreX, int centreY);
  float trackedHotX = 15.5f;
  float trackedHotY = 11.5f;
  float trackedColdX = 15.5f;
  float trackedColdY = 11.5f;
};
