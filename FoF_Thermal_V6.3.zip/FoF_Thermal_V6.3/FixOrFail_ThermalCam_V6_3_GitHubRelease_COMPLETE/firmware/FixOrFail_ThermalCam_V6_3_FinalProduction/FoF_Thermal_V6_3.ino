#include <Arduino.h>
#include <ctype.h>
#include <Preferences.h>
#include "Config.h"
#include "Camera.h"
#include "Display.h"
#include "Palette.h"
#include "ThermalProcessing.h"
#include "UI.h"
#include "Touch.h"

Camera thermalCamera;
Display thermalDisplay;
UI thermalUI;
ThermalProcessing processing;
TouchController touch;
Preferences preferences;

float rawGrid[PIXEL_COUNT];
float filteredGrid[PIXEL_COUNT];
ThermalStats stats;

float displayMinimum = 15.0f;
float displayMaximum = 35.0f;
float calibrationOffset = 0.0f;

bool firstFrame = true;
bool freezeFrame = false;
bool autoRange = true;
bool electronicsMode = true;
bool mirrorImage = false;
bool minMaxHold = false;
bool isothermEnabled = false;
// V3.0 three-point inspection measurement system. Display-only; thermal data is untouched.
constexpr uint8_t MEASUREMENT_POINT_COUNT = 3;
bool measurementEnabled[MEASUREMENT_POINT_COUNT] = {false, false, false};
int measurementScreenX[MEASUREMENT_POINT_COUNT] = {
  IMAGE_X + IMAGE_WIDTH / 2, IMAGE_X + IMAGE_WIDTH / 3, IMAGE_X + (IMAGE_WIDTH * 2) / 3
};
int measurementScreenY[MEASUREMENT_POINT_COUNT] = {
  IMAGE_Y + IMAGE_HEIGHT / 2, IMAGE_Y + IMAGE_HEIGHT / 2, IMAGE_Y + IMAGE_HEIGHT / 2
};
float measurementTemperature[MEASUREMENT_POINT_COUNT] = {0.0f, 0.0f, 0.0f};
uint8_t nextMeasurementPoint = 0;

float isothermThreshold = 50.0f;
float heldMinimum = 999.0f;
float heldMaximum = -999.0f;
uint8_t zoomLevel = 1;
PaletteMode paletteMode = PALETTE_IRONBOW;

uint32_t lastFrameTime = 0;
uint32_t lastUiUpdate = 0;
uint32_t rejectedFrames = 0;
float filteredFPS = 0.0f;

// V6.0.1 non-blocking reliability diagnostics. These counters do not affect
// the thermal/rendering pipeline; they only observe runtime health.
uint32_t successfulFrames = 0;
uint32_t readTimeouts = 0;
uint32_t decodeFailures = 0;
uint32_t minimumFreeHeap = 0xFFFFFFFFu;
uint32_t maximumGoodFrameGapMs = 0;
bool bugDiagnosticsActive = false;
uint32_t bugDiagnosticsStartedMs = 0;
uint32_t bugDiagBaseSuccessful = 0;
uint32_t bugDiagBaseTimeouts = 0;
uint32_t bugDiagBaseDecodeFailures = 0;
constexpr uint32_t BUG_DIAGNOSTIC_DURATION_MS = 20000;

// V6.0.2 focused UART/UI stress profiler. Command U runs three 10-second phases:
// idle -> UI stress -> recovery idle.
bool uartStressActive = false;
uint32_t uartStressStartMs = 0;
uint8_t uartStressPhase = 0;
uint32_t maxUiServiceMsPhase = 0;
uint32_t maxRenderMsPhase = 0;
uint32_t maxReadAttemptGapMsPhase = 0;
uint32_t lastReadAttemptMsStress = 0;
CameraUartDiagnostics uartPhaseBase;
uint32_t goodPhaseBase = 0;
uint32_t decodePhaseBase = 0;
uint32_t timeoutPhaseBase = 0;

// V3.0 display-only smart hotspot tracker. The measured temperature grid is untouched.
bool hotspotTrackerInitialised = false;
float trackedHotX = SENSOR_WIDTH * 0.5f;
float trackedHotY = SENSOR_HEIGHT * 0.5f;
float trackedHotTemperature = 0.0f;
constexpr float HOTSPOT_TRACK_RESPONSE = 0.28f;
constexpr float HOTSPOT_TRACK_FAST_RESPONSE = 0.62f;
constexpr float HOTSPOT_FAST_JUMP_PIXELS = 5.0f;

// V2.3 persistent user settings (ESP32 NVS).
// V4.1 appliance-style runtime state.
bool bootComplete = false;
bool sensorOnline = false;
bool sensorStatusDrawn = false;
uint8_t consecutiveFrameFailures = 0;
uint32_t lastGoodFrameMs = 0;
uint32_t lastSensorStatusMs = 0;

bool settingsDirty = false;
uint32_t settingsDirtySince = 0;
constexpr uint32_t SETTINGS_SAVE_DELAY_MS = 750;

// V6.0 Ultimate Final: premium single-entry UI, no bottom tabs, matched full-screen orientation.
bool fullScreenMode = DEFAULT_START_FULLSCREEN;
bool startFullScreen = DEFAULT_START_FULLSCREEN;
bool cleanMode = DEFAULT_CLEAN_MODE;
bool temperatureScaleEnabled = DEFAULT_TEMPERATURE_SCALE;
bool fullScreenControlsVisible = false;
uint32_t fullScreenControlsUntil = 0;
int centreCardX = 8;
int centreCardY = 30;
int statsCardX = 226;
int statsCardY = 30;
int inspectionCardX = PROBE_CARD_X;
int inspectionCardY = PROBE_CARD_Y;
bool inspectionCardUserVisible = true;
enum DragCard : uint8_t { DRAG_NONE = 0, DRAG_CENTRE, DRAG_STATS, DRAG_INSPECTION };
DragCard dragCandidate = DRAG_NONE;
DragCard activeDrag = DRAG_NONE;
uint32_t dragPressStart = 0;
int dragOffsetX = 0, dragOffsetY = 0;
uint32_t lastDragDrawMs = 0;

void markSettingsDirty()
{
  settingsDirty = true;
  settingsDirtySince = millis();
}

void loadSettings()
{
  preferences.begin("fof-thermal", true);
  electronicsMode = preferences.getBool("repair", electronicsMode);
  autoRange = preferences.getBool("autoRange", autoRange);
  mirrorImage = preferences.getBool("mirror", mirrorImage);
  minMaxHold = preferences.getBool("minMaxHold", minMaxHold);
  isothermEnabled = preferences.getBool("isoEnabled", isothermEnabled);
  isothermThreshold = constrain(preferences.getFloat("isoTemp", isothermThreshold),
                                ISOTHERM_MIN_C, ISOTHERM_MAX_C);
  calibrationOffset = constrain(preferences.getFloat("calOffset", calibrationOffset),
                                -20.0f, 20.0f);
  zoomLevel = preferences.getUChar("zoom", zoomLevel);
  if (zoomLevel != 1 && zoomLevel != 2 && zoomLevel != 4) zoomLevel = 1;
  const uint8_t savedPalette = preferences.getUChar("palette", static_cast<uint8_t>(paletteMode));
  if (savedPalette < static_cast<uint8_t>(PALETTE_COUNT)) {
    paletteMode = static_cast<PaletteMode>(savedPalette);
  }
  cleanMode = preferences.getBool("cleanMode", cleanMode);
  startFullScreen = preferences.getBool("startFull", startFullScreen);
  temperatureScaleEnabled = preferences.getBool("tempScale", temperatureScaleEnabled);
  fullScreenMode = startFullScreen;
  centreCardX = constrain(preferences.getInt("ctrX", centreCardX), 0, SCREEN_WIDTH - CENTRE_CARD_W);
  centreCardY = constrain(preferences.getInt("ctrY", centreCardY), HEADER_HEIGHT, SCREEN_HEIGHT - NAV_HEIGHT - CENTRE_CARD_H);
  statsCardX = constrain(preferences.getInt("statX", statsCardX), 0, SCREEN_WIDTH - STATS_CARD_W);
  statsCardY = constrain(preferences.getInt("statY", statsCardY), HEADER_HEIGHT, SCREEN_HEIGHT - NAV_HEIGHT - STATS_CARD_H);
  inspectionCardX = constrain(preferences.getInt("inspX", inspectionCardX), 0, SCREEN_WIDTH - PROBE_CARD_W);
  inspectionCardY = constrain(preferences.getInt("inspY", inspectionCardY), HEADER_HEIGHT, SCREEN_HEIGHT - NAV_HEIGHT - PROBE_CARD_H);
  inspectionCardUserVisible = preferences.getBool("inspVis", inspectionCardUserVisible);
  preferences.end();
}

void saveSettingsNow()
{
  preferences.begin("fof-thermal", false);
  preferences.putBool("repair", electronicsMode);
  preferences.putBool("autoRange", autoRange);
  preferences.putBool("mirror", mirrorImage);
  preferences.putBool("minMaxHold", minMaxHold);
  preferences.putBool("isoEnabled", isothermEnabled);
  preferences.putFloat("isoTemp", isothermThreshold);
  preferences.putFloat("calOffset", calibrationOffset);
  preferences.putUChar("zoom", zoomLevel);
  preferences.putUChar("palette", static_cast<uint8_t>(paletteMode));
  preferences.putBool("cleanMode", cleanMode);
  preferences.putBool("startFull", startFullScreen);
  preferences.putBool("tempScale", temperatureScaleEnabled);
  preferences.putInt("ctrX", centreCardX); preferences.putInt("ctrY", centreCardY);
  preferences.putInt("statX", statsCardX); preferences.putInt("statY", statsCardY);
  preferences.putInt("inspX", inspectionCardX); preferences.putInt("inspY", inspectionCardY);
  preferences.putBool("inspVis", inspectionCardUserVisible);
  preferences.end();
  settingsDirty = false;
}

void serviceSettingsSave()
{
  if (settingsDirty && millis() - settingsDirtySince >= SETTINGS_SAVE_DELAY_MS) {
    saveSettingsNow();
  }
}

void applyCalibration()
{
  if (calibrationOffset == 0.0f) return;
  for (int i = 0; i < PIXEL_COUNT; ++i) filteredGrid[i] += calibrationOffset;
}

void resetHolds() { heldMinimum = stats.minimum; heldMaximum = stats.maximum; }

void updateHolds()
{
  if (!minMaxHold) { resetHolds(); return; }
  heldMinimum = min(heldMinimum, stats.minimum);
  heldMaximum = max(heldMaximum, stats.maximum);
}

void calculateRobustSceneRange(float& robustMinimum, float& robustMaximum)
{
  // Display-only percentile range. A few extreme pixels no longer wash out
  // the complete picture, while all temperature measurements remain untouched.
  constexpr int BIN_COUNT = 64;
  uint16_t bins[BIN_COUNT] = {0};

  const float rawMinimum = stats.minimum;
  const float rawMaximum = stats.maximum;
  const float rawSpan = rawMaximum - rawMinimum;

  if (rawSpan < 0.05f) {
    robustMinimum = rawMinimum;
    robustMaximum = rawMaximum;
    return;
  }

  for (int i = 0; i < PIXEL_COUNT; ++i) {
    const float normalised = constrain(
      (filteredGrid[i] - rawMinimum) / rawSpan,
      0.0f,
      1.0f
    );
    const int bin = min(
      static_cast<int>(normalised * static_cast<float>(BIN_COUNT)),
      BIN_COUNT - 1
    );
    ++bins[bin];
  }

  const uint16_t lowTarget =
    static_cast<uint16_t>(PIXEL_COUNT * DISPLAY_LOW_PERCENTILE);
  const uint16_t highTarget =
    static_cast<uint16_t>(PIXEL_COUNT * DISPLAY_HIGH_PERCENTILE);

  uint16_t cumulative = 0;
  int lowBin = 0;
  int highBin = BIN_COUNT - 1;

  for (int i = 0; i < BIN_COUNT; ++i) {
    cumulative += bins[i];
    if (cumulative >= lowTarget) {
      lowBin = i;
      break;
    }
  }

  cumulative = 0;
  for (int i = 0; i < BIN_COUNT; ++i) {
    cumulative += bins[i];
    if (cumulative >= highTarget) {
      highBin = i;
      break;
    }
  }

  robustMinimum = rawMinimum +
    (static_cast<float>(lowBin) / static_cast<float>(BIN_COUNT - 1)) * rawSpan;
  robustMaximum = rawMinimum +
    (static_cast<float>(highBin) / static_cast<float>(BIN_COUNT - 1)) * rawSpan;
}

void updateDisplayRange()
{
  if (!autoRange) return;

  float robustMinimum;
  float robustMaximum;
  calculateRobustSceneRange(robustMinimum, robustMaximum);

  float targetMinimum;
  float targetMaximum;
  float response = RANGE_RESPONSE;

  if (electronicsMode) {
    // Keep hot components visible while rejecting isolated cold background pixels.
    targetMinimum = max(robustMinimum - 0.3f, stats.average - 2.4f);
    targetMaximum = max(robustMaximum + 0.5f, stats.maximum - 0.4f);
    float span = constrain(
      targetMaximum - targetMinimum,
      ELECTRONICS_MIN_SPAN_C,
      ELECTRONICS_MAX_SPAN_C
    );
    targetMinimum = targetMaximum - span;
    response = ELECTRONICS_RANGE_RESPONSE;
  } else {
    targetMinimum = robustMinimum - RANGE_MARGIN_C;
    targetMaximum = robustMaximum + RANGE_MARGIN_C;
  }

  if (targetMaximum - targetMinimum < MINIMUM_RANGE_SPAN_C) {
    const float middle = (targetMinimum + targetMaximum) * 0.5f;
    targetMinimum = middle - MINIMUM_RANGE_SPAN_C * 0.5f;
    targetMaximum = middle + MINIMUM_RANGE_SPAN_C * 0.5f;
  }

  if (firstFrame) {
    displayMinimum = targetMinimum;
    displayMaximum = targetMaximum;
    return;
  }

  // A small deadband stops tiny sensor changes from making the palette breathe.
  if (fabsf(targetMinimum - displayMinimum) < RANGE_DEADBAND_C) {
    targetMinimum = displayMinimum;
  }
  if (fabsf(targetMaximum - displayMaximum) < RANGE_DEADBAND_C) {
    targetMaximum = displayMaximum;
  }

  // Expand quickly when the scene changes, contract gently to prevent flicker.
  const float minimumResponse =
    targetMinimum < displayMinimum ? RANGE_ATTACK_RESPONSE : response;
  const float maximumResponse =
    targetMaximum > displayMaximum ? RANGE_ATTACK_RESPONSE : response;

  displayMinimum += (targetMinimum - displayMinimum) * minimumResponse;
  displayMaximum += (targetMaximum - displayMaximum) * maximumResponse;
}

void updateFPS(uint32_t now)
{
  if (lastFrameTime != 0) {
    const uint32_t elapsed = now - lastFrameTime;
    if (elapsed) {
      const float current = 1000.0f / elapsed;
      filteredFPS = filteredFPS <= 0.0f ? current : filteredFPS * 0.82f + current * 0.18f;
    }
  }
  lastFrameTime = now;
}

float sampleTemperatureAtScreen(int screenX, int screenY)
{
  float nx = static_cast<float>(screenX - IMAGE_X) / static_cast<float>(IMAGE_WIDTH - 1);
  float ny = static_cast<float>(screenY - IMAGE_Y) / static_cast<float>(IMAGE_HEIGHT - 1);
  nx = constrain(nx, 0.0f, 1.0f);
  ny = constrain(ny, 0.0f, 1.0f);

  const float zoom = static_cast<float>(zoomLevel);
  nx = (nx - 0.5f) / zoom + 0.5f;
  ny = (ny - 0.5f) / zoom + 0.5f;
  nx = constrain(nx, 0.0f, 1.0f);
  ny = constrain(ny, 0.0f, 1.0f);
  if (mirrorImage) nx = 1.0f - nx;

  const float sx = nx * static_cast<float>(SENSOR_WIDTH - 1);
  const float sy = ny * static_cast<float>(SENSOR_HEIGHT - 1);
  const int x0 = static_cast<int>(sx);
  const int y0 = static_cast<int>(sy);
  const int x1 = min(x0 + 1, SENSOR_WIDTH - 1);
  const int y1 = min(y0 + 1, SENSOR_HEIGHT - 1);
  const float fx = sx - x0;
  const float fy = sy - y0;
  const float top = filteredGrid[y0 * SENSOR_WIDTH + x0] * (1.0f - fx) +
                    filteredGrid[y0 * SENSOR_WIDTH + x1] * fx;
  const float bottom = filteredGrid[y1 * SENSOR_WIDTH + x0] * (1.0f - fx) +
                       filteredGrid[y1 * SENSOR_WIDTH + x1] * fx;
  return top * (1.0f - fy) + bottom * fy;
}

void updateSmartHotspotTracker()
{
  const int hottest = constrain(stats.hottestPixel, 0, PIXEL_COUNT - 1);
  const int hx = hottest % SENSOR_WIDTH;
  const int hy = hottest / SENSOR_WIDTH;

  // Build a small temperature-weighted centroid around the hottest pixel.
  // This rejects one-pixel noise and prevents the marker jumping between neighbours.
  float weightedX = 0.0f;
  float weightedY = 0.0f;
  float weightSum = 0.0f;
  const float floorTemp = stats.maximum - 2.0f;
  for (int oy = -1; oy <= 1; ++oy) {
    const int y = constrain(hy + oy, 0, SENSOR_HEIGHT - 1);
    for (int ox = -1; ox <= 1; ++ox) {
      const int x = constrain(hx + ox, 0, SENSOR_WIDTH - 1);
      const float t = filteredGrid[y * SENSOR_WIDTH + x];
      const float weight = max(0.05f, t - floorTemp + 0.10f);
      weightedX += static_cast<float>(x) * weight;
      weightedY += static_cast<float>(y) * weight;
      weightSum += weight;
    }
  }

  const float targetX = weightSum > 0.0f ? weightedX / weightSum : static_cast<float>(hx);
  const float targetY = weightSum > 0.0f ? weightedY / weightSum : static_cast<float>(hy);

  if (!hotspotTrackerInitialised) {
    trackedHotX = targetX;
    trackedHotY = targetY;
    hotspotTrackerInitialised = true;
  } else {
    const float dx = targetX - trackedHotX;
    const float dy = targetY - trackedHotY;
    const float distanceSquared = dx * dx + dy * dy;
    const float response = distanceSquared > HOTSPOT_FAST_JUMP_PIXELS * HOTSPOT_FAST_JUMP_PIXELS
      ? HOTSPOT_TRACK_FAST_RESPONSE : HOTSPOT_TRACK_RESPONSE;
    trackedHotX += dx * response;
    trackedHotY += dy * response;
  }

  trackedHotTemperature = stats.maximum;
}

void applyRepairPreset()
{
  electronicsMode = true;
  autoRange = true;
  paletteMode = PALETTE_IRONBOW;
  zoomLevel = 1;
  minMaxHold = false;
  isothermEnabled = false;
  buildPalette(thermalDisplay.tft(), paletteMode);
        thermalUI.invalidateDynamicOverlays();
  resetHolds();
  markSettingsDirty();
}

void factoryResetSettings()
{
  preferences.begin("fof-thermal", false);
  preferences.clear();
  preferences.end();
  delay(80);
  ESP.restart();
}

bool rectanglesOverlap(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh)
{
  return ax < bx + bw && ax + aw > bx && ay < by + bh && ay + ah > by;
}

void snapCardsToSafePositions(DragCard moved)
{
  if (moved == DRAG_INSPECTION) {
    // Keep the inspection panel exactly where the user releases it; just make
    // sure the complete panel remains inside the usable live-view area.
    inspectionCardX = constrain(inspectionCardX, 0, SCREEN_WIDTH - PROBE_CARD_W);
    inspectionCardY = constrain(inspectionCardY, HEADER_HEIGHT,
                                SCREEN_HEIGHT - NAV_HEIGHT - PROBE_CARD_H);
    thermalDisplay.setInspectionCardRect(inspectionCardX, inspectionCardY);
    return;
  }

  auto snapOne = [](int& x, int& y, int w, int h) {
    x = (x + w / 2 < SCREEN_WIDTH / 2) ? 8 : SCREEN_WIDTH - w - 8;
    const int usableTop = HEADER_HEIGHT + 6;
    const int usableBottom = SCREEN_HEIGHT - h - 6;
    const int middle = (usableTop + usableBottom) / 2;
    y = (y + h / 2 < middle) ? usableTop : usableBottom;
  };
  if (moved == DRAG_CENTRE) snapOne(centreCardX, centreCardY, CENTRE_CARD_W, CENTRE_CARD_H);
  else if (moved == DRAG_STATS) snapOne(statsCardX, statsCardY, STATS_CARD_W, STATS_CARD_H);

  if (rectanglesOverlap(centreCardX, centreCardY, CENTRE_CARD_W, CENTRE_CARD_H,
                        statsCardX, statsCardY, STATS_CARD_W, STATS_CARD_H)) {
    if (moved == DRAG_CENTRE) centreCardY = (centreCardY < SCREEN_HEIGHT / 2)
      ? SCREEN_HEIGHT - NAV_HEIGHT - CENTRE_CARD_H - 6 : HEADER_HEIGHT + 6;
    else statsCardY = (statsCardY < SCREEN_HEIGHT / 2)
      ? SCREEN_HEIGHT - NAV_HEIGHT - STATS_CARD_H - 6 : HEADER_HEIGHT + 6;
  }
}

void configureDisplayProtection();

void showFullScreenControls()
{
  fullScreenControlsVisible = true;
  fullScreenControlsUntil = millis() + FULLSCREEN_CONTROLS_TIMEOUT_MS;
  configureDisplayProtection();
  thermalUI.drawFullScreenControls(thermalDisplay.tft(), freezeFrame, autoRange, cleanMode);
}

void printDiagnostics()
{
  Serial.println("\n===== FIX OR FAIL V6.3 FINAL DIAGNOSTICS =====");
  Serial.printf("FPS: %.2f\n", filteredFPS);
  Serial.printf("Free heap: %u bytes\n", ESP.getFreeHeap());
  Serial.printf("Rejected frames: %u\n", rejectedFrames);
  Serial.printf("Range: %.1fC to %.1fC\n", displayMinimum, displayMaximum);
  Serial.printf("Scene mode: %s\n", electronicsMode ? "REPAIR" : "GENERAL");
  Serial.printf("Isotherm: %s at %.1fC\n", isothermEnabled ? "ON" : "OFF", isothermThreshold);
  Serial.printf("Centre: %.1fC  Min: %.1fC  Max: %.1fC\n",
                stats.spot, stats.minimum, stats.maximum);
  Serial.print("Measurement points:");
  for (uint8_t i = 0; i < MEASUREMENT_POINT_COUNT; ++i) {
    if (measurementEnabled[i]) {
      Serial.printf(" P%u=%.1fC", static_cast<unsigned>(i + 1), measurementTemperature[i]);
    }
  }
  Serial.println();
  Serial.printf("Good frames: %u  Read timeouts: %u  Decode failures: %u\n",
                successfulFrames, readTimeouts, decodeFailures);
  Serial.printf("Min free heap: %u bytes  Max good-frame gap: %u ms\n",
                minimumFreeHeap == 0xFFFFFFFFu ? ESP.getFreeHeap() : minimumFreeHeap,
                maximumGoodFrameGapMs);
  Serial.printf("Sensor: %s  Touch calibration: %s\n",
                sensorOnline ? "ONLINE" : "OFFLINE",
                touch.hasSavedCalibration() ? "SAVED" : "MISSING");
  const CameraUartDiagnostics ud = thermalCamera.uartDiagnostics();
  Serial.printf("UART repaired frames: %u  repaired pixels: %u  corrupt rejected: %u\n",
                ud.repairedFrames, ud.repairedPixels, ud.corruptRejectedFrames);
  Serial.printf("UART RX high-water: %u / %u bytes  skipped sync bytes: %u\n",
                ud.maxQueuedBytes, static_cast<unsigned>(UART_RX_BUFFER_BYTES), ud.skippedBytes);
  Serial.printf("Last good frame age: %u ms\n",
                lastGoodFrameMs ? millis() - lastGoodFrameMs : 0u);
  Serial.println("========================================\n");
}


void resetUartStressPhaseCounters()
{
  uartPhaseBase = thermalCamera.uartDiagnostics();
  goodPhaseBase = successfulFrames;
  decodePhaseBase = decodeFailures;
  timeoutPhaseBase = readTimeouts;
  maxUiServiceMsPhase = 0;
  maxRenderMsPhase = 0;
  maxReadAttemptGapMsPhase = 0;
  lastReadAttemptMsStress = 0;
}

void printUartStressPhase(const char* name)
{
  const CameraUartDiagnostics d = thermalCamera.uartDiagnostics();
  Serial.printf("\n--- UART STRESS PHASE: %s ---\n", name);
  Serial.printf("Good frames: %u  loop-read failures: %u  decode failures: %u\n",
    successfulFrames - goodPhaseBase, readTimeouts - timeoutPhaseBase, decodeFailures - decodePhaseBase);
  Serial.printf("Parser accepted: %u  search timeout: %u  short: %u  bad length: %u\n",
    d.acceptedFrames - uartPhaseBase.acceptedFrames,
    d.searchTimeouts - uartPhaseBase.searchTimeouts,
    d.shortFrames - uartPhaseBase.shortFrames,
    d.badLengths - uartPhaseBase.badLengths);
  Serial.printf("Invalid-temp frames: %u  skipped sync bytes: %u  max skipped/header: %u\n",
    d.invalidTemperatureFrames - uartPhaseBase.invalidTemperatureFrames,
    d.skippedBytes - uartPhaseBase.skippedBytes,
    d.maxSkippedBeforeHeader);
  Serial.printf("RX queued high-water: %u bytes  UI max: %u ms  render max: %u ms  read-gap max: %u ms\n",
    d.maxQueuedBytes, maxUiServiceMsPhase, maxRenderMsPhase, maxReadAttemptGapMsPhase);
  if (d.invalidTemperatureFrames > uartPhaseBase.invalidTemperatureFrames)
    Serial.printf("Last invalid temp: pixel %u raw=%u (%.2fC)\n", d.lastInvalidPixel, d.lastInvalidRaw, d.lastInvalidRaw / 100.0f);
  if (d.badLengths > uartPhaseBase.badLengths)
    Serial.printf("Last bad payload length: %u (expected %u)\n", d.lastBadLength, EXPECTED_PAYLOAD_LENGTH);
}

void startUartStressTest()
{
  thermalCamera.resetUartDiagnostics();
  uartStressActive = true;
  uartStressStartMs = millis();
  uartStressPhase = 0;
  resetUartStressPhaseCounters();
  Serial.println("\n===== 30 SECOND FOCUSED UART STRESS TEST =====");
  Serial.println("PHASE 1 (0-10s): DO NOT TOUCH THE SCREEN.");
}

void serviceUartStressTest()
{
  if (!uartStressActive) return;
  const uint32_t elapsed = millis() - uartStressStartMs;
  if (uartStressPhase == 0 && elapsed >= 10000) {
    printUartStressPhase("IDLE");
    uartStressPhase = 1; resetUartStressPhaseCounters();
    Serial.println("PHASE 2 (10-20s): USE MENU, FULL SCREEN, MOVE CARDS/INSPECTION.");
  } else if (uartStressPhase == 1 && elapsed >= 20000) {
    printUartStressPhase("UI STRESS");
    uartStressPhase = 2; resetUartStressPhaseCounters();
    Serial.println("PHASE 3 (20-30s): STOP TOUCHING. LET IT RECOVER.");
  } else if (uartStressPhase == 2 && elapsed >= 30000) {
    printUartStressPhase("RECOVERY IDLE");
    uartStressActive = false;
    const CameraUartDiagnostics d = thermalCamera.uartDiagnostics();
    Serial.println("\n===== UART ROOT-CAUSE SUMMARY DATA =====");
    Serial.printf("Total parser accepted: %u\n", d.acceptedFrames);
    Serial.printf("Search timeouts: %u  Short frames: %u  Bad lengths: %u\n", d.searchTimeouts, d.shortFrames, d.badLengths);
    Serial.printf("Invalid-temperature frames: %u\n", d.invalidTemperatureFrames);
    Serial.printf("Total skipped sync bytes: %u  Max skipped before header: %u\n", d.skippedBytes, d.maxSkippedBeforeHeader);
    Serial.printf("RX queue high-water: %u bytes\n", d.maxQueuedBytes);
    Serial.println("Paste the full three-phase report into ChatGPT for classification.");
    Serial.println("========================================\n");
  }
}

void startBugDiagnostics()
{
  bugDiagnosticsActive = true;
  bugDiagnosticsStartedMs = millis();
  bugDiagBaseSuccessful = successfulFrames;
  bugDiagBaseTimeouts = readTimeouts;
  bugDiagBaseDecodeFailures = decodeFailures;
  minimumFreeHeap = ESP.getFreeHeap();
  maximumGoodFrameGapMs = 0;
  Serial.println("\n===== 20 SECOND BUG / STABILITY TEST STARTED =====");
  Serial.println("Use the camera normally: touch menu, move cards, toggle full-screen.");
  Serial.println("Do not unplug it until the PASS/WARN report appears.\n");
}

void serviceBugDiagnostics()
{
  const uint32_t heapNow = ESP.getFreeHeap();
  if (heapNow < minimumFreeHeap) minimumFreeHeap = heapNow;
  if (!bugDiagnosticsActive) return;
  if (millis() - bugDiagnosticsStartedMs < BUG_DIAGNOSTIC_DURATION_MS) return;

  bugDiagnosticsActive = false;
  const uint32_t good = successfulFrames - bugDiagBaseSuccessful;
  const uint32_t timeouts = readTimeouts - bugDiagBaseTimeouts;
  const uint32_t decodes = decodeFailures - bugDiagBaseDecodeFailures;
  const uint32_t attempts = good + timeouts + decodes;
  const float rejectPct = attempts ? (100.0f * (timeouts + decodes) / attempts) : 100.0f;

  const bool sensorPass = sensorOnline && good >= 10;
  const bool fpsPass = filteredFPS >= 0.5f;
  const bool memoryPass = minimumFreeHeap >= 50000u;
  const bool touchPass = touch.hasSavedCalibration();
  const bool tempPass = isfinite(stats.minimum) && isfinite(stats.maximum) &&
                        stats.minimum >= MIN_VALID_TEMP_C && stats.maximum <= MAX_VALID_TEMP_C &&
                        stats.maximum >= stats.minimum;
  const bool overall = sensorPass && fpsPass && memoryPass && touchPass && tempPass;

  Serial.println("\n================ BUG DIAGNOSTIC REPORT ================");
  Serial.printf("Overall:             %s\n", overall ? "PASS" : "CHECK WARNINGS");
  Serial.printf("Sensor stream:       %s  (%u valid frames)\n", sensorPass ? "PASS" : "WARN", good);
  Serial.printf("Frame rejection:     %.1f%%  (%u timeout, %u decode)\n", rejectPct, timeouts, decodes);
  Serial.printf("Displayed FPS:       %.2f  [%s]\n", filteredFPS, fpsPass ? "PASS" : "WARN");
  Serial.printf("Minimum free heap:   %u bytes  [%s]\n", minimumFreeHeap, memoryPass ? "PASS" : "WARN");
  Serial.printf("Touch calibration:   %s\n", touchPass ? "PASS" : "WARN - RECALIBRATE");
  Serial.printf("Temperature sanity:  %s  (%.1fC .. %.1fC)\n", tempPass ? "PASS" : "WARN", stats.minimum, stats.maximum);
  Serial.printf("Max good-frame gap:  %u ms\n", maximumGoodFrameGapMs);
  if (rejectPct > 30.0f) Serial.println("WARN: High UART/frame rejection rate. Check camera wiring/baud/power.");
  if (!memoryPass) Serial.println("WARN: Low heap headroom. Watch for UI crashes after long use.");
  if (!sensorPass) Serial.println("WARN: Thermal stream was not consistently online.");
  Serial.println("=======================================================\n");
}

void printHelp()
{
  Serial.println("\n========== FIX OR FAIL THERMAL CAMERA V6.3 FINAL PRODUCTION ==========");
  Serial.println("P palette        F freeze");
  Serial.println("E repair/general A auto/locked range");
  Serial.println("M mirror         Z zoom 1/2/4");
  Serial.println("H min/max hold   C clear hold");
  Serial.println("I isotherm       +/- isotherm threshold");
  Serial.println("[/] calibration offset -/+ 0.1C");
  Serial.println("R reset range    T 8-point touch calibration");
  Serial.println("D diagnostics    B 20-second bug/stability test");
  Serial.println("U focused 30-second UART/UI root-cause test");
  Serial.println("X clear measurement points");
  Serial.println("Tap P1/P2/P3 to show/hide inspection; hold card to drag");
  Serial.println("Y clean mode     V full-screen view");
  Serial.println("UI controls: top-left Android menu; no bottom tabs");
  Serial.println("? help");
  Serial.println("========================================\n");
}

void configureDisplayProtection()
{
  thermalDisplay.setFullScreen(fullScreenMode);
  thermalDisplay.setInspectionCardRect(inspectionCardX, inspectionCardY);
  thermalDisplay.setTemperatureScaleReserved(fullScreenMode && temperatureScaleEnabled);
  thermalDisplay.setTopOverlayReserved(fullScreenMode && fullScreenControlsVisible);
  if (fullScreenMode && cleanMode) {
    thermalDisplay.setInfoCardRects(true, CLEAN_CARD_X, CLEAN_CARD_Y, SCREEN_WIDTH + 20, 0);
  } else {
    thermalDisplay.setInfoCardRects(!fullScreenMode, centreCardX, centreCardY, statsCardX, statsCardY);
  }
}

void redrawLayout()
{
  thermalUI.drawHomeChrome(thermalDisplay.tft(), paletteMode, freezeFrame, autoRange, zoomLevel, fullScreenMode);
}

void redrawLiveImageNow()
{
  if (firstFrame) return;

  thermalDisplay.setInspectionCardVisible(!fullScreenMode && inspectionCardUserVisible &&
    (measurementEnabled[0] || measurementEnabled[1] || measurementEnabled[2]));
  configureDisplayProtection();
  thermalDisplay.renderImage(filteredGrid, displayMinimum, displayMaximum,
    mirrorImage, zoomLevel, isothermEnabled, isothermThreshold);

  if (fullScreenMode) {
    if (temperatureScaleEnabled) thermalUI.drawTemperatureScale(thermalDisplay.tft(), displayMinimum, displayMaximum);
    if (cleanMode) {
      thermalUI.drawHotspotOnly(thermalDisplay.tft(), trackedHotX, trackedHotY, trackedHotTemperature, mirrorImage, zoomLevel);
      thermalUI.drawCleanOverlay(thermalDisplay.tft(), stats.spot, trackedHotTemperature);
    }
    if (fullScreenControlsVisible) thermalUI.drawFullScreenControls(thermalDisplay.tft(), freezeFrame, autoRange, cleanMode);
    return;
  }

  thermalUI.drawCrosshair(thermalDisplay.tft());
  thermalUI.drawSmartHotspot(thermalDisplay.tft(), trackedHotX, trackedHotY,
    trackedHotTemperature, stats.coldestPixel, mirrorImage, zoomLevel);
  for (uint8_t i = 0; i < MEASUREMENT_POINT_COUNT; ++i) {
    if (measurementEnabled[i]) {
      measurementTemperature[i] = sampleTemperatureAtScreen(
        measurementScreenX[i], measurementScreenY[i]);
    }
  }
  thermalUI.drawMeasurementPoints(thermalDisplay.tft(), measurementEnabled,
    measurementScreenX, measurementScreenY, measurementTemperature,
    inspectionCardX, inspectionCardY, inspectionCardUserVisible);
  thermalUI.updateOverlay(thermalDisplay.tft(), stats.spot,
    minMaxHold ? heldMinimum : stats.minimum,
    minMaxHold ? heldMaximum : stats.maximum, filteredFPS, freezeFrame,
    isothermEnabled, isothermThreshold, centreCardX, centreCardY,
    statsCardX, statsCardY, false);
  redrawLayout();
}

// UI page state must be declared before any function that uses it.
bool menuOpen = false;
bool systemMenuOpen = false;
bool diagnosticsOpen = false;
bool aboutOpen = false;
bool resetArmed = false;
uint32_t resetArmedAt = 0;

void handleSerialControls()
{
  while (Serial.available()) {
    const char c = static_cast<char>(Serial.read());
    const char command = static_cast<char>(toupper(c));

    switch (command) {
      case 'P':
        paletteMode = nextPalette(paletteMode);
        buildPalette(thermalDisplay.tft(), paletteMode);
        thermalUI.invalidateDynamicOverlays();
        redrawLayout();
        markSettingsDirty();
        break;
      case 'F': freezeFrame = !freezeFrame; break;
      case 'E':
        if (!electronicsMode) applyRepairPreset();
        else { electronicsMode = false; autoRange = true; markSettingsDirty(); }
        break;
      case 'A': autoRange = !autoRange; markSettingsDirty(); break;
      case 'M': mirrorImage = !mirrorImage; markSettingsDirty(); break;
      case 'Z': zoomLevel = zoomLevel == 1 ? 2 : (zoomLevel == 2 ? 4 : 1); markSettingsDirty(); break;
      case 'H': minMaxHold = !minMaxHold; resetHolds(); markSettingsDirty(); break;
      case 'C': resetHolds(); break;
      case 'I': isothermEnabled = !isothermEnabled; markSettingsDirty(); break;
      case '+': case '=': isothermThreshold = min(isothermThreshold + ISOTHERM_STEP_C, ISOTHERM_MAX_C); markSettingsDirty(); break;
      case '-': case '_': isothermThreshold = max(isothermThreshold - ISOTHERM_STEP_C, ISOTHERM_MIN_C); markSettingsDirty(); break;
      case '[': calibrationOffset = max(calibrationOffset - 0.1f, -20.0f); markSettingsDirty(); break;
      case ']': calibrationOffset = min(calibrationOffset + 0.1f, 20.0f); markSettingsDirty(); break;
      case 'T':
        touch.runEightPointCalibration(thermalDisplay.tft());
        redrawLayout();
        markSettingsDirty();
        break;
      case 'R':
        displayMinimum = stats.minimum - RANGE_MARGIN_C;
        displayMaximum = stats.maximum + RANGE_MARGIN_C;
        autoRange = true;
        markSettingsDirty();
        break;
      case 'Y': cleanMode = !cleanMode; thermalUI.invalidateDynamicOverlays(); markSettingsDirty(); break;
      case 'V': fullScreenMode = !fullScreenMode; thermalUI.invalidateDynamicOverlays(); configureDisplayProtection(); redrawLiveImageNow(); break;
      case 'B':
        startBugDiagnostics();
        break;
      case 'U':
        startUartStressTest();
        break;
      case 'D':
        printDiagnostics();
        diagnosticsOpen = true;
        thermalUI.showDiagnostics(thermalDisplay.tft(), filteredFPS, ESP.getFreeHeap(),
          rejectedFrames, displayMinimum, displayMaximum, stats.spot,
          stats.minimum, stats.maximum, paletteMode, zoomLevel);
        break;
      case 'X':
        for (uint8_t i = 0; i < MEASUREMENT_POINT_COUNT; ++i) measurementEnabled[i] = false;
        nextMeasurementPoint = 0;
        redrawLiveImageNow();
        break;
      case '?': printHelp(); break;
      default: break;
    }
  }
}


bool pointInRect(int x, int y, int rx, int ry, int rw, int rh)
{
  return x >= rx && x < rx + rw && y >= ry && y < ry + rh;
}

bool pointNearMeasurementMarker(int x, int y)
{
  constexpr int HIT_RADIUS = 14;
  for (uint8_t i = 0; i < MEASUREMENT_POINT_COUNT; ++i) {
    if (!measurementEnabled[i]) continue;
    if (abs(x - measurementScreenX[i]) <= HIT_RADIUS &&
        abs(y - measurementScreenY[i]) <= HIT_RADIUS) return true;
  }
  return false;
}

bool serviceCardDrag()
{
  if (fullScreenMode || menuOpen || diagnosticsOpen) {
    dragCandidate = DRAG_NONE; activeDrag = DRAG_NONE; return false;
  }

  int x, y;
  const bool pressed = touch.readContinuous(x, y);
  if (!pressed) {
    if (activeDrag != DRAG_NONE) {
      const DragCard moved = activeDrag;
      activeDrag = DRAG_NONE; dragCandidate = DRAG_NONE;
      snapCardsToSafePositions(moved);
      markSettingsDirty();
      redrawLiveImageNow();
      return true;
    }
    if (dragCandidate != DRAG_NONE) {
      if (dragCandidate == DRAG_INSPECTION) {
        inspectionCardUserVisible = false;
        thermalDisplay.setInspectionCardVisible(false);
        markSettingsDirty();
        redrawLiveImageNow();
      }
      dragCandidate = DRAG_NONE;
      return true;
    }
    return false;
  }

  if (activeDrag == DRAG_NONE && dragCandidate == DRAG_NONE) {
    if (pointInRect(x, y, centreCardX, centreCardY, CENTRE_CARD_W, CENTRE_CARD_H)) {
      dragCandidate = DRAG_CENTRE; dragOffsetX = x - centreCardX; dragOffsetY = y - centreCardY;
    } else if (pointInRect(x, y, statsCardX, statsCardY, STATS_CARD_W, STATS_CARD_H)) {
      dragCandidate = DRAG_STATS; dragOffsetX = x - statsCardX; dragOffsetY = y - statsCardY;
    } else if (inspectionCardUserVisible &&
               (measurementEnabled[0] || measurementEnabled[1] || measurementEnabled[2]) &&
               pointInRect(x, y, inspectionCardX, inspectionCardY, PROBE_CARD_W, PROBE_CARD_H)) {
      dragCandidate = DRAG_INSPECTION;
      dragOffsetX = x - inspectionCardX; dragOffsetY = y - inspectionCardY;
    } else return false;
    dragPressStart = millis();
    return true;
  }

  if (activeDrag == DRAG_NONE && dragCandidate != DRAG_NONE &&
      millis() - dragPressStart >= CARD_LONG_PRESS_MS) {
    activeDrag = dragCandidate;
  }

  if (activeDrag != DRAG_NONE && millis() - lastDragDrawMs >= CARD_DRAG_UPDATE_MS) {
    if (activeDrag == DRAG_CENTRE) {
      centreCardX = constrain(x - dragOffsetX, 0, SCREEN_WIDTH - CENTRE_CARD_W);
      centreCardY = constrain(y - dragOffsetY, HEADER_HEIGHT, SCREEN_HEIGHT - NAV_HEIGHT - CENTRE_CARD_H);
    } else if (activeDrag == DRAG_STATS) {
      statsCardX = constrain(x - dragOffsetX, 0, SCREEN_WIDTH - STATS_CARD_W);
      statsCardY = constrain(y - dragOffsetY, HEADER_HEIGHT, SCREEN_HEIGHT - NAV_HEIGHT - STATS_CARD_H);
    } else if (activeDrag == DRAG_INSPECTION) {
      inspectionCardX = constrain(x - dragOffsetX, 0, SCREEN_WIDTH - PROBE_CARD_W);
      inspectionCardY = constrain(y - dragOffsetY, HEADER_HEIGHT, SCREEN_HEIGHT - NAV_HEIGHT - PROBE_CARD_H);
      thermalDisplay.setInspectionCardRect(inspectionCardX, inspectionCardY);
      thermalDisplay.setInspectionCardVisible(true);
      thermalUI.drawMeasurementPoints(thermalDisplay.tft(), measurementEnabled,
        measurementScreenX, measurementScreenY, measurementTemperature,
        inspectionCardX, inspectionCardY, true);
      lastDragDrawMs = millis();
      return true;
    }
    thermalDisplay.setInfoCardRects(true, centreCardX, centreCardY, statsCardX, statsCardY);
    thermalUI.updateOverlay(thermalDisplay.tft(), stats.spot,
      minMaxHold ? heldMinimum : stats.minimum, minMaxHold ? heldMaximum : stats.maximum,
      filteredFPS, freezeFrame, isothermEnabled, isothermThreshold,
      centreCardX, centreCardY, statsCardX, statsCardY, false);
    lastDragDrawMs = millis();
  }
  return true;
}

void handleTouchControls()
{
  int x, y;
  if (!touch.readTap(x, y)) return;

  if (diagnosticsOpen || aboutOpen) {
    diagnosticsOpen = false;
    aboutOpen = false;
    redrawLiveImageNow();
    return;
  }

  if (fullScreenMode && !menuOpen) {
    // First touch reveals controls; they disappear automatically after a few seconds.
    if (!fullScreenControlsVisible) {
      showFullScreenControls();
      return;
    }

    // Five compact full-screen buttons: UI, palette, hold, auto/lock, menu.
    if (y >= QUICK_BAR_Y && y < QUICK_BAR_Y + QUICK_BUTTON_H) {
      const int step = 60 + QUICK_BUTTON_GAP;
      const int index = (x - 5) / step;
      if (x >= 5 && index >= 0 && index < 5) {
        const int bx = 5 + index * step;
        if (x >= bx && x < bx + 60) {
          switch (index) {
            case 0:
              fullScreenMode = false;
              fullScreenControlsVisible = false;
              thermalUI.invalidateDynamicOverlays();
              configureDisplayProtection();
              redrawLiveImageNow();
              return;
            case 1:
              paletteMode = nextPalette(paletteMode);
              buildPalette(thermalDisplay.tft(), paletteMode);
        thermalUI.invalidateDynamicOverlays();
              markSettingsDirty();
              break;
            case 2: freezeFrame = !freezeFrame; break;
            case 3: autoRange = !autoRange; markSettingsDirty(); break;
            case 4:
              menuOpen = true;
              systemMenuOpen = false;
              fullScreenControlsVisible = false;
              configureDisplayProtection();
              thermalUI.drawMenu(thermalDisplay.tft(), electronicsMode, mirrorImage,
                                 minMaxHold, isothermEnabled, isothermThreshold);
              return;
          }
          showFullScreenControls();
          return;
        }
      }
    }

    // A second touch away from the controls hides them cleanly.
    fullScreenControlsVisible = false;
    configureDisplayProtection();
    redrawLiveImageNow();
    return;
  }

  // Short taps on temperature cards are ignored; hold to drag.
  if (!menuOpen && (pointInRect(x, y, centreCardX, centreCardY, CENTRE_CARD_W, CENTRE_CARD_H) ||
      pointInRect(x, y, statsCardX, statsCardY, STATS_CARD_W, STATS_CARD_H))) return;

  if (!menuOpen && ((!fullScreenMode && pointInRect(x, y, FULLSCREEN_BUTTON_X, FULLSCREEN_BUTTON_Y,
                                                     FULLSCREEN_BUTTON_W, FULLSCREEN_BUTTON_H)))) {
    fullScreenMode = true;
    fullScreenControlsVisible = false;
    thermalUI.invalidateDynamicOverlays();
    configureDisplayProtection();
    redrawLiveImageNow();
    return;
  }

  if (!menuOpen && (y < HEADER_HEIGHT && x < 34)) {
    menuOpen = true;
    systemMenuOpen = false;
    thermalUI.drawMenu(thermalDisplay.tft(), electronicsMode, mirrorImage,
                       minMaxHold, isothermEnabled, isothermThreshold);
    return;
  }

  // V6.0: no bottom touch tabs; all controls live in the Android-style menu.

  if (!menuOpen && y >= IMAGE_Y && y < IMAGE_Y + IMAGE_HEIGHT) {
    // Tapping an existing P1/P2/P3 marker toggles the inspection card. This
    // gives a quick way to hide it for an unobstructed thermal view and bring
    // it back without deleting the measurement points.
    if (pointNearMeasurementMarker(x, y)) {
      inspectionCardUserVisible = !inspectionCardUserVisible;
      markSettingsDirty();
      redrawLiveImageNow();
      return;
    }

    const uint8_t point = nextMeasurementPoint;
    measurementEnabled[point] = true;
    measurementScreenX[point] = constrain(x, IMAGE_X + 10, IMAGE_X + IMAGE_WIDTH - 11);
    measurementScreenY[point] = constrain(y, IMAGE_Y + 10, IMAGE_Y + IMAGE_HEIGHT - 11);
    nextMeasurementPoint = (nextMeasurementPoint + 1) % MEASUREMENT_POINT_COUNT;
    if (!firstFrame) measurementTemperature[point] = sampleTemperatureAtScreen(measurementScreenX[point], measurementScreenY[point]);
    return;
  }

  if (!menuOpen) return;

  if (x < 38 || x > 282 || y < 24 || y > 216) {
    menuOpen = false; systemMenuOpen = false; resetArmed = false;
    thermalUI.closeMenu(thermalDisplay.tft()); redrawLiveImageNow(); return;
  }

  if (systemMenuOpen) {
    if (resetArmed && millis() - resetArmedAt > 4000) resetArmed = false;
    if (y >= 61 && y < 88) { cleanMode = !cleanMode; thermalUI.invalidateDynamicOverlays(); }
    else if (y >= 92 && y < 119) startFullScreen = !startFullScreen;
    else if (y >= 123 && y < 150) { temperatureScaleEnabled = !temperatureScaleEnabled; thermalUI.invalidateDynamicOverlays(); }
    else if (y >= 188 && y < 211 && x >= 50 && x < 118) {
      menuOpen = false; systemMenuOpen = false;
      thermalUI.showAbout(thermalDisplay.tft(), sensorOnline, touch.hasSavedCalibration(), millis()/1000UL);
      aboutOpen = true; return;
    }
    else if (y >= 188 && y < 211 && x >= 126 && x < 194) {
      if (!resetArmed) { resetArmed = true; resetArmedAt = millis(); }
      else factoryResetSettings();
    }
    else if (y >= 188 && y < 211 && x >= 202 && x < 270) {
      systemMenuOpen = false; resetArmed = false;
      thermalUI.drawMenu(thermalDisplay.tft(), electronicsMode, mirrorImage,
                         minMaxHold, isothermEnabled, isothermThreshold); return;
    }
    markSettingsDirty();
    thermalUI.drawSystemMenu(thermalDisplay.tft(), cleanMode, startFullScreen,
                             temperatureScaleEnabled, resetArmed);
    return;
  }

  if (y >= 61 && y < 88) {
    if (!electronicsMode) applyRepairPreset();
    else { electronicsMode = false; autoRange = true; markSettingsDirty(); }
  }
  else if (y >= 92 && y < 119) mirrorImage = !mirrorImage;
  else if (y >= 123 && y < 150) { minMaxHold = !minMaxHold; resetHolds(); }
  else if (y >= 154 && y < 181) {
    if (x >= 138 && x < 168) isothermThreshold = max(isothermThreshold - ISOTHERM_STEP_C, ISOTHERM_MIN_C);
    else if (x >= 232 && x < 270) isothermThreshold = min(isothermThreshold + ISOTHERM_STEP_C, ISOTHERM_MAX_C);
    else isothermEnabled = !isothermEnabled;
  }
  else if (y >= 188 && y < 211 && x >= 50 && x < 118) {
    menuOpen = false; thermalUI.closeMenu(thermalDisplay.tft());
    touch.runEightPointCalibration(thermalDisplay.tft()); redrawLiveImageNow(); return;
  }
  else if (y >= 188 && y < 211 && x >= 126 && x < 194) {
    menuOpen = false; diagnosticsOpen = true; thermalUI.closeMenu(thermalDisplay.tft());
    thermalUI.showDiagnostics(thermalDisplay.tft(), filteredFPS, ESP.getFreeHeap(), rejectedFrames,
      displayMinimum, displayMaximum, stats.spot, stats.minimum, stats.maximum, paletteMode, zoomLevel); return;
  }
  else if (y >= 188 && y < 211 && x >= 202 && x < 270) {
    systemMenuOpen = true;
    thermalUI.drawSystemMenu(thermalDisplay.tft(), cleanMode, startFullScreen,
                             temperatureScaleEnabled, resetArmed); return;
  }

  markSettingsDirty();
  thermalUI.drawMenu(thermalDisplay.tft(), electronicsMode, mirrorImage,
                     minMaxHold, isothermEnabled, isothermThreshold);
}

void setup()
{
  // V6.2 INSTANT USB BOOT: never wait for USB enumeration or Serial Monitor.
  // Start the thermal UART before drawing the splash screen so the hardware RX
  // queue is already collecting sensor bytes while the display initialises.
  Serial.begin(115200);
  thermalCamera.begin();

  // Immediate visual startup. There are no intentional boot delays/status-page
  // pauses on a calibrated production unit.
  thermalDisplay.begin();
  thermalUI.showBootScreen(thermalDisplay.tft());

  touch.begin(thermalDisplay.spi());
  loadSettings();
  fullScreenMode = startFullScreen;
  configureDisplayProtection();
  buildPalette(thermalDisplay.tft(), paletteMode);
  thermalUI.invalidateDynamicOverlays();

  // Calibration is the only intentional blocking path, and only happens once
  // on a unit that has no saved calibration.
  if (!touch.hasSavedCalibration()) {
    touch.runEightPointCalibration(thermalDisplay.tft());
  }

  Serial.println("\nFIX OR FAIL THERMAL CAMERA V6.3 FINAL PRODUCTION");
  Serial.println("V6.3 FINAL: validated V6.2 stable core + smooth renderer + robust UART + instant USB boot");
  printHelp();
}

void loop()
{
  const uint32_t uiStartMs = millis();
  handleSerialControls();
  const bool draggingCards = serviceCardDrag();
  if (!draggingCards) handleTouchControls();
  serviceSettingsSave();
  serviceBugDiagnostics();
  serviceUartStressTest();
  if (uartStressActive) {
    const uint32_t uiElapsed = millis() - uiStartMs;
    if (uiElapsed > maxUiServiceMsPhase) maxUiServiceMsPhase = uiElapsed;
  }

  if (fullScreenControlsVisible && millis() > fullScreenControlsUntil) {
    fullScreenControlsVisible = false;
    configureDisplayProtection();
    if (freezeFrame && fullScreenMode && !firstFrame) redrawLiveImageNow();
  }

  if (diagnosticsOpen || aboutOpen) {
    delay(8);
    return;
  }

  if (freezeFrame) {
    // Touch is already serviced once at the top of loop(). Avoid a second read and
    // redraw only the small overlay at the normal UI interval.
    const uint32_t now = millis();
    if (!menuOpen && (firstFrame || now - lastUiUpdate >= UI_UPDATE_INTERVAL_MS)) {
      thermalUI.updateOverlay(thermalDisplay.tft(), stats.spot,
        minMaxHold ? heldMinimum : stats.minimum,
        minMaxHold ? heldMaximum : stats.maximum, filteredFPS, true,
        isothermEnabled, isothermThreshold, centreCardX, centreCardY, statsCardX, statsCardY, fullScreenMode);
      lastUiUpdate = now;
    }
    delay(8);
    return;
  }

  if (uartStressActive) {
    const uint32_t readNow = millis();
    if (lastReadAttemptMsStress != 0) {
      const uint32_t rg = readNow - lastReadAttemptMsStress;
      if (rg > maxReadAttemptGapMsPhase) maxReadAttemptGapMsPhase = rg;
    }
    lastReadAttemptMsStress = readNow;
  }
  if (!thermalCamera.readFrame(SENSOR_READ_SLICE_MS)) {
    ++rejectedFrames;
    ++readTimeouts;
    if (consecutiveFrameFailures < 255) ++consecutiveFrameFailures;

    // V6.2 parser continuously searches for the next valid header/length pair.
    // Do not flush the deep RX queue here; flushing can discard good frames that
    // arrived while the display was busy.

    if (consecutiveFrameFailures >= SENSOR_OFFLINE_FAILURES) {
      sensorOnline = false;
      if (!bootComplete) {
        thermalUI.showBootStatus(thermalDisplay.tft(), "WAITING FOR SENSOR", false);
      } else if (!fullScreenMode && (!sensorStatusDrawn || millis() - lastSensorStatusMs >= SENSOR_STATUS_REFRESH_MS)) {
        thermalUI.updateSensorStatus(thermalDisplay.tft(), false);
        sensorStatusDrawn = true;
        lastSensorStatusMs = millis();
      }
    }
    delay(1);
    return;
  }

  if (!thermalCamera.decodeFrame(rawGrid, filteredGrid, firstFrame)) {
    ++rejectedFrames;
    ++decodeFailures;
    if (consecutiveFrameFailures < 255) ++consecutiveFrameFailures;
    return;
  }

  consecutiveFrameFailures = 0;
  sensorOnline = true;
  const uint32_t goodFrameNow = millis();
  if (lastGoodFrameMs != 0) {
    const uint32_t gap = goodFrameNow - lastGoodFrameMs;
    if (gap > maximumGoodFrameGapMs) maximumGoodFrameGapMs = gap;
  }
  lastGoodFrameMs = goodFrameNow;
  ++successfulFrames;

  applyCalibration();
  processing.calculateStats(filteredGrid, stats);
  processing.updateStableExtremes(filteredGrid, stats, firstFrame);
  updateSmartHotspotTracker();
  updateHolds();
  updateDisplayRange();

  const uint32_t now = millis();
  updateFPS(now);

  if (!bootComplete) {
    // First valid frame is the immediate hand-off from splash to live camera.
    redrawLayout();
    bootComplete = true;
    sensorStatusDrawn = false;
  }

  if (!fullScreenMode && (!sensorStatusDrawn || now - lastSensorStatusMs >= SENSOR_STATUS_REFRESH_MS)) {
    thermalUI.updateSensorStatus(thermalDisplay.tft(), true);
    sensorStatusDrawn = true;
    lastSensorStatusMs = now;
  }

  if (!menuOpen) {
    thermalDisplay.setInspectionCardVisible(!fullScreenMode && inspectionCardUserVisible &&
      (measurementEnabled[0] || measurementEnabled[1] || measurementEnabled[2]));
    configureDisplayProtection();
    const uint32_t renderStartMsStress = millis();
    thermalDisplay.renderImage(filteredGrid, displayMinimum, displayMaximum,
      mirrorImage, zoomLevel, isothermEnabled, isothermThreshold);
    if (uartStressActive) {
      const uint32_t rd = millis() - renderStartMsStress;
      if (rd > maxRenderMsPhase) maxRenderMsPhase = rd;
    }
    if (!fullScreenMode) {
      thermalUI.drawCrosshair(thermalDisplay.tft());
      thermalUI.drawSmartHotspot(thermalDisplay.tft(), trackedHotX, trackedHotY,
        trackedHotTemperature, stats.coldestPixel, mirrorImage, zoomLevel);
      for (uint8_t i = 0; i < MEASUREMENT_POINT_COUNT; ++i) {
        if (measurementEnabled[i]) measurementTemperature[i] = sampleTemperatureAtScreen(measurementScreenX[i], measurementScreenY[i]);
      }
      thermalUI.drawMeasurementPoints(thermalDisplay.tft(), measurementEnabled,
        measurementScreenX, measurementScreenY, measurementTemperature,
        inspectionCardX, inspectionCardY, inspectionCardUserVisible);
    } else {
      if (temperatureScaleEnabled) thermalUI.drawTemperatureScale(thermalDisplay.tft(), displayMinimum, displayMaximum);
      if (cleanMode) {
        thermalUI.drawHotspotOnly(thermalDisplay.tft(), trackedHotX, trackedHotY, trackedHotTemperature, mirrorImage, zoomLevel);
        thermalUI.drawCleanOverlay(thermalDisplay.tft(), stats.spot, trackedHotTemperature);
      } else {
        thermalUI.drawHotspotOnly(thermalDisplay.tft(), trackedHotX, trackedHotY, trackedHotTemperature, mirrorImage, zoomLevel);
      }
      if (fullScreenControlsVisible) thermalUI.drawFullScreenControls(thermalDisplay.tft(), freezeFrame, autoRange, cleanMode);
    }
  }

  if (!menuOpen && (firstFrame || now - lastUiUpdate >= UI_UPDATE_INTERVAL_MS)) {
    thermalUI.updateOverlay(thermalDisplay.tft(), stats.spot,
      minMaxHold ? heldMinimum : stats.minimum,
      minMaxHold ? heldMaximum : stats.maximum, filteredFPS, false,
      isothermEnabled, isothermThreshold, centreCardX, centreCardY, statsCardX, statsCardY, fullScreenMode);
    lastUiUpdate = now;
  }

  firstFrame = false;
}
