# Contributing

Bug reports should include:

- ESP32-S3 board model,
- thermal sensor model,
- display/touch model,
- firmware version,
- Arduino/ESP32 core version,
- complete `D` diagnostic output,
- complete `U` stress-test output when the issue involves frame loss, lag or corruption,
- exact wiring changes from the documented pinout.

Keep thermal measurement logic separate from display-only image enhancement whenever possible.
